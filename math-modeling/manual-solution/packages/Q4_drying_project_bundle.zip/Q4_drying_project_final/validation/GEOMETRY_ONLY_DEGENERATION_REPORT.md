# Q4 Geometry Core — Degeneration Test Report

## 1. Purpose

This test validates only the **Q4 moving-geometry core**, before coupling it to the temperature/moisture PDE solver.

The implemented modeling assumption is:

\[
r(\xi,t)=\xi R(t),\qquad 0\le \xi\le1,
\]

with constant axial length and affine radial material shrinkage.

The final material-coordinate PDE uses the geometric factor

\[
\frac1{R(t)^2}
\]

but does **not** require \(\dot R(t)\) explicitly. The code still provides \(\dot R(t)\) for diagnostics and material-velocity visualization:

\[
u(\xi,t)=\xi\dot R(t).
\]

---

## 2. Attachment 2 data check

`附件2.xlsx` contains:

- 145 radius samples;
- time range: 0–72 h;
- sampling interval: 0.5 h = 1800 s;
- radius: 2.000 cm → 1.198 cm;
- strictly monotone non-increasing radius data.

Representative measured radii:

| Time | Radius |
|---:|---:|
| 0 h | 2.000 cm |
| 6 h | 1.374 cm |
| 12 h | 1.248 cm |
| 24 h | 1.204 cm |
| 36 h | 1.200 cm |
| 72 h | 1.198 cm |

The main geometry implementation therefore uses:

\[
R(t)=\text{piecewise-linear interpolation of Attachment 2},
\]

and for \(t>72\) h:

\[
R(t)=1.198\ {\rm cm}.
\]

At the midpoint of the first measurement interval:

\[
R(0.25h)=1.9365\ {\rm cm}.
\]

The first-segment slope is:

\[
\dot R=-7.05556\times10^{-7}\ {\rm m/s}.
\]

Because piecewise-linear \(R(t)\) has derivative jumps at measurement knots, `dRdt()` requires an explicit left/right/average convention. This derivative is diagnostic only; it is not needed by the final material-coordinate PDE.

---

## 3. Fixed-radius geometry degeneration

Set

\[
R(t)\equiv R_0=0.02\ {\rm m}.
\]

Using \(N=128\), the Q4 material grid produces exactly the same physical geometry as the fixed Q2/Q3 cylindrical grid:

- maximum face-coordinate difference: 0;
- maximum cell-center difference: 0;
- maximum face-area difference: 0;
- maximum cell-volume difference: 0.

Therefore:

\[
\boxed{\text{Q4 geometry } \xrightarrow{R(t)=R_0} \text{ Q2/Q3 fixed geometry}}
\]

is satisfied exactly to floating-point representation.

---

## 4. Fixed-radius diffusion-operator degeneration

For a nontrivial smooth test field \(u(\xi)\) and variable coefficient \(k(\xi)\), the same cell-centered cylindrical finite-volume diffusion operator was assembled in two ways:

1. directly in physical radius \(r\);
2. on the material coordinate \(\xi\) using the transformed \(1/R^2\) geometry factor.

At fixed radius:

\[
\max
\frac{|L_r-L_\xi|}
{\max|L_r|}
=
2.99\times10^{-15}.
\]

Thus the transformed operator degenerates to the Q2/Q3 physical-grid operator to machine precision.

---

## 5. Robin derivative degeneration

Q4 surface derivative:

\[
u_r(R)
=
\frac1R u_\xi(1).
\]

With the same second-order surface reconstruction,

\[
u_\xi(1)
\approx
\frac{8u_s-9u_{N-1}+u_{N-2}}{3\Delta\xi},
\]

the Q4 expression becomes:

\[
u_r(R)
\approx
\frac{8u_s-9u_{N-1}+u_{N-2}}
{3R\Delta\xi}.
\]

Since:

\[
\Delta r=R\Delta\xi,
\]

this is exactly the Q2/Q3 formula:

\[
u_r(R)
\approx
\frac{8u_s-9u_{N-1}+u_{N-2}}
{3\Delta r}.
\]

The numerical degeneration-test difference was exactly 0.

---

## 6. Analytic constant-speed shrink test

Use the artificial radius law:

\[
R(t)=R_0+vt
\]

with:

\[
R_0=0.02{\rm\,m},\qquad
v=-2\times10^{-7}{\rm\,m/s}.
\]

At the selected test time:

\[
R/R_0=0.8.
\]

The geometry core returns:

\[
A/A_0=0.8,
\]

\[
V/V_0=0.64=0.8^2,
\]

\[
\frac{A/V}{A_0/V_0}=1.25=\frac1{0.8}.
\]

Therefore:

\[
\boxed{A\propto R,\qquad V\propto R^2,\qquad A/V\propto1/R.}
\]

The material velocity also satisfies exactly:

\[
u(\xi,t)=\xi v.
\]

---

## 7. \(1/R^2\) diffusion scaling test

For the same material-coordinate field and coefficient distribution, changing only the radius from:

\[
R_0\rightarrow0.8R_0
\]

must multiply the transformed cylindrical diffusion operator by:

\[
\left(\frac{R_0}{R}\right)^2
=
\frac1{0.8^2}
=
1.5625.
\]

The observed mean factor was:

\[
1.5625,
\]

with maximum ratio error:

\[
4.44\times10^{-16}.
\]

This directly verifies the Q4 transformed geometry factor:

\[
\boxed{\frac1{R(t)^2}.}
\]

---

## 8. Consistency test using the actual measured shrinkage

The physical-coordinate FVM operator and the mapped \(\xi\)-coordinate operator were compared at:

\[
t=0,\ 6,\ 12,\ 24,\ 36,\ 72,\ 80{\rm\,h}.
\]

The maximum relative difference remained below approximately:

\[
3\times10^{-14}.
\]

Representative geometric scaling:

| Time | \(R\) (cm) | \(A/A_0\) | \(V/V_0\) | \((A/V)/(A_0/V_0)\) |
|---:|---:|---:|---:|---:|
| 0 h | 2.000 | 1.000 | 1.000000 | 1.0000 |
| 6 h | 1.374 | 0.687 | 0.471969 | 1.4556 |
| 12 h | 1.248 | 0.624 | 0.389376 | 1.6026 |
| 24 h | 1.204 | 0.602 | 0.362404 | 1.6611 |
| 36 h | 1.200 | 0.600 | 0.360000 | 1.6667 |
| 72 h | 1.198 | 0.599 | 0.358801 | 1.6694 |
| 80 h | 1.198 | 0.599 | 0.358801 | 1.6694 |

The 80 h row verifies the constant-radius extension after the end of Attachment 2.

---

## 9. Dry-basis state under pure affine geometry change

For a uniform dry-basis moisture field:

\[
C(\xi)=C_0,
\]

the material-coordinate annular weighted mean is:

\[
\bar C_d
=
\frac{\sum_i w_iC_i}{\sum_iw_i},
\qquad
w_i=\xi_{i+1/2}^2-\xi_{i-1/2}^2.
\]

Pure affine shrinkage changes physical volume, but does not by itself change the dry-basis moisture ratio. The test returns the original uniform value exactly to floating-point precision.

This is consistent with the modeling conclusion that no artificial:

\[
C\nabla\cdot u
\]

source should be added to the dry-basis moisture equation.

---

# Final result

All geometry-only tests pass.

\[
\boxed{\text{Attachment-2 radius handling: PASS}}
\]

\[
\boxed{\text{Q4 -> Q2/Q3 fixed-radius degeneration: PASS}}
\]

\[
\boxed{\text{physical FVM -> mapped FVM operator equivalence: PASS}}
\]

\[
\boxed{\text{Robin derivative degeneration: PASS}}
\]

\[
\boxed{\text{area/volume shrink scaling: PASS}}
\]

\[
\boxed{\text{diffusion }1/R^2\text{ scaling: PASS}}
\]

The geometry core is therefore ready to be coupled to the Q4 heat/moisture RHS.

## Next recommended test before full Q4 production

The next layer should add the Q4 PDE RHS and perform:

1. **full fixed-radius PDE degeneration**: freeze \(R(t)=0.02\) m and verify the Q4 solver reproduces the corresponding fixed-domain Appendix-4 solver;
2. center and Robin residual tests on the transformed grid;
3. water integral balance:
   \[
   \frac{d\bar C_d}{dt}
   =
   -\frac{2h_m}{R(t)}(C_s-C_\infty);
   \]
4. grid convergence in \(\Delta\xi\);
5. actual-shrink vs Appendix-4 fixed-radius controlled comparison.
