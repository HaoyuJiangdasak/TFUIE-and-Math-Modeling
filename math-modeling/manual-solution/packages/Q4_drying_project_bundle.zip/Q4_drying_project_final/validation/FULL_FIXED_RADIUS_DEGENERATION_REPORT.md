# Q4 Full Fixed-Radius Degeneration Test Report

## Purpose

This is the mandatory regression test before trusting the moving-radius Q4 solver.

Q4 is frozen at

\[
R(t)\equiv R_0=0.02\ {\rm m}
\]

and compared against an independently assembled physical-radius cylindrical FVM using the **same Appendix-4 material laws**.

The two implementations are independent at the spatial/RHS level:

1. Q4 material-coordinate implementation on \(\xi\in[0,1]\);
2. direct physical-\(r\) fixed-domain reference implementation.

The test includes geometry, nonlinear Robin values, the full coupled RHS, dry-basis balance, an end-to-end 0-4 h BDF trajectory, output reconstruction, and the terminal-event functional.

## Appendix-4 properties used

\[
\rho(C)=760+90C,
\]

\[
c_p(C)=1850+2150\frac{C}{C+1},
\]

\[
k(C)=0.12+0.20\frac{C}{C+1},
\]

\[
D(C,T_K)=4.2\times10^{-4}
\exp(-0.30/C)\exp(-3850/T_K).
\]

## Test results

| Test | Error |
|---|---:|
| face geometry | 0 |
| center geometry | 0 |
| \(\Delta r=R\Delta\xi\) | 0 |
| surface \(T_s,C_s\), \(t=0\) | 0 |
| surface \(T_s,C_s\), \(t=1234\) s | 0 |
| surface \(T_s,C_s\), \(t=7200\) s | 0 |
| surface \(T_s,C_s\), \(t=14399\) s | 0 |
| full RHS relative error, representative states | \(1.0\times10^{-15}\) to \(2.6\times10^{-15}\) |
| dry-basis balance relative error | \(1.25\times10^{-16}\) |
| 0-4 h BDF trajectory: max \(|\Delta T|\) | \(2.65\times10^{-6}\ ^\circ\mathrm C\) |
| 0-4 h BDF trajectory: max \(|\Delta C|\) | \(3.33\times10^{-9}\) |
| output reconstruction max \(|\Delta T|\) | \(1.11\times10^{-7}\ ^\circ\mathrm C\) |
| output reconstruction max \(|\Delta C|\) | \(4.96\times10^{-10}\) |
| event-function value error | 0 |
| event maximum-location error | 0 |

The small difference between the two 0-4 h BDF trajectories is adaptive-integrator path noise: the independently assembled RHS functions already agree to machine precision. The trajectory discrepancy is many orders below the problem's four-decimal reporting precision.

## Result

\[
\boxed{\text{FULL FIXED-RADIUS PDE DEGENERATION: PASS}}
\]

Therefore, when \(R(t)\equiv R_0\),

\[
\boxed{
\text{Q4 mapped PDE}
\longrightarrow
\text{Appendix-4 fixed-radius cylindrical PDE}
}
\]

not only geometrically, but also at the Robin, coupled-RHS, BDF-trajectory, postprocessing, balance, and event-functional levels.

## Moving-radius smoke test

After the degeneration test passed, the actual Attachment-2 radius history was enabled.

Development settings:

- \(N=160\);
- BDF;
- relaxed development tolerances;
- measured piecewise-linear radius history;
- Q3 long-term environment extension.

The solver reached:

\[
t_{\rm dry}\approx184289.47\ {\rm s}
=51.19152\ {\rm h}.
\]

At the event:

\[
C_{\max}=0.15,
\qquad
\xi_{\max}=0,
\qquad
R(t_{\rm dry})\approx1.200\ {\rm cm}.
\]

The local surface Picard solver used zero fallback root solves.

Instantaneous balance checks were approximately:

\[
R_{\rm heat}\sim2.1\times10^{-16},
\]

\[
R_{\rm moisture}\sim2.8\times10^{-16}.
\]

The development run used a coarse 600 s output interval for one cumulative-balance smoke test, giving about 0.58% trapezoidal integration residual. This is **not** a production accuracy result. Formal Q4 validation must use the required 60 s output and the strict production configuration.

## What remains before final Q4 reporting

1. event-time grid convergence: \(N=320,640,1280\);
2. BDF/event tolerance sensitivity;
3. linear vs PCHIP radius interpolation sensitivity;
4. Appendix-4 fixed-radius vs shrinking-radius controlled comparison;
5. final \(N=1280\) production solution;
6. 60 s dry-basis cumulative balance;
7. Table 6 and official `result4.xlsx` template filling.
