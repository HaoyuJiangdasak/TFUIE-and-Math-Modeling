# Q4 Moving-Radius Drying Project

This project extends the validated Q3 long-time framework to Question 4.

## Formal numerical route

\[
\boxed{
\text{Appendix-4 properties}
+
r=\xi R(t)
+
\text{cell-centered cylindrical FVM on }\xi
+
\text{joint BDF}
+
\text{local coupled Robin Picard}
+
\text{full-state terminal event}
}
\]

The main radius model is the piecewise-linear interpolation of `附件2.xlsx`.
PCHIP is implemented only as a sensitivity alternative.

## Mandatory regression status

The full fixed-radius degeneration test has passed.

See:

`validation/FULL_FIXED_RADIUS_DEGENERATION_REPORT.md`

and run:

```bash
python tests/test_q4_fixed_radius_degeneracy.py
```

before trusting a modified Q4 solver.

## Environment

Conda:

```bash
conda env create -f environment.yml
conda activate q4_drying
python -m ipykernel install --user --name q4_drying --display-name "Python (q4_drying)"
```

or venv:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -r requirements.txt
```

Windows activation:

```powershell
.venv\Scripts\activate
```

## Development analysis

Open:

`notebooks/Q4_analysis.ipynb`

Run the fixed-radius regression first. The heavy formal convergence and production cells are disabled by default and can be enabled one by one.

## Production command

```bash
python src/q4_solver.py \
  --env data/附件1.xlsx \
  --radius data/附件2.xlsx \
  --output outputs/result4.xlsx \
  --N 1280 \
  --radius-mode linear
```

If the official result4 workbook is available:

```bash
python src/q4_solver.py \
  --env data/附件1.xlsx \
  --radius data/附件2.xlsx \
  --template data/result4_template.xlsx \
  --output outputs/result4.xlsx \
  --N 1280
```

## Output rule

`result4.xlsx` uses fixed physical-distance columns from 0 to 1.9 cm plus a separate surface column.

At a time \(t\):

- if \(r_j<R(t)\), interpolate the material-coordinate solution at \(\xi=r_j/R(t)\);
- if \(r_j>R(t)\), leave the cell blank;
- the surface column always uses the nonlinear Robin boundary-face value.

The exact terminal time is reported separately and does not need to be a 60 s multiple.

## Recommended formal workflow

1. fixed-radius full PDE degeneration;
2. moving-radius moderate-grid diagnostics;
3. 320/640/1280 drying-time convergence;
4. time/event sensitivity;
5. linear/PCHIP radius sensitivity;
6. Appendix-4 fixed-radius vs measured-shrink comparison;
7. final N=1280 solve;
8. dry-basis balance;
9. Table 6;
10. official result4 output.
