from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import math
import sys
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from q3_solver import LongTermEnvironment
from q4_geometry_core import MaterialGrid, ConstantRadius
from q2_solver import jacobian_sparsity
from q4_solver import (
    Q4Parameters, Q4Config,
    density4, heat_capacity4, thermal_conductivity4, moisture_diffusivity4,
    k_faces4, D_faces4, coupled_surface_q4, q4_rhs,
    center_reconstruction, augmented_cmax_q4, sample_q4_state,
)

Array = np.ndarray


@dataclass(frozen=True)
class PhysicalGrid:
    N: int
    R: float
    faces: Array
    centers: Array
    dr: float
    area: Array
    volume: Array

    @classmethod
    def build(cls, N: int, R: float) -> "PhysicalGrid":
        faces = np.linspace(0.0, R, N+1)
        dr = R/N
        centers = (np.arange(N)+0.5)*dr
        area = 2.0*faces                 # common pi*L removed
        volume = faces[1:]**2-faces[:-1]**2
        return cls(N,R,faces,centers,dr,area,volume)


def surface_map_ref(Cs,Tp,Tpp,Cp,Cpp,Tinf,Cinf,dr,p):
    k=float(thermal_conductivity4(Cs))
    Ts=(k*(9*Tp-Tpp)+3*dr*p.h*Tinf)/(8*k+3*dr*p.h)
    D=float(moisture_diffusivity4(Cs,Ts))
    Cr=(D*(9*Cp-Cpp)+3*dr*p.hm*Cinf)/(8*D+3*dr*p.hm)
    return float(Ts),float(Cr)


def surface_ref(T,C,t,grid,env,p,cfg):
    Tp,Tpp=float(T[-1]),float(T[-2])
    Cp,Cpp=float(C[-1]),float(C[-2])
    Tinf=float(env.T_inf(t)); Cinf=float(env.C_inf(t))
    Cs=max(Cp,1e-12)
    Ts,_=surface_map_ref(Cs,Tp,Tpp,Cp,Cpp,Tinf,Cinf,grid.dr,p)
    prev=None; omega=cfg.surface_relaxation
    for it in range(1,cfg.surface_max_iter+1):
        _,raw=surface_map_ref(Cs,Tp,Tpp,Cp,Cpp,Tinf,Cinf,grid.dr,p)
        delta=raw-Cs
        if prev is not None and delta*prev<0 and abs(delta)>0.8*abs(prev):
            omega=max(0.15,0.5*omega)
        Cn=omega*raw+(1-omega)*Cs
        Tn,_=surface_map_ref(Cn,Tp,Tpp,Cp,Cpp,Tinf,Cinf,grid.dr,p)
        if abs(Tn-Ts)<=cfg.surface_tol_T and abs(Cn-Cs)<=cfg.surface_tol_C:
            return float(Tn),float(Cn),it
        prev=delta; Ts,Cs=Tn,Cn

    def f(x):
        return x-surface_map_ref(x,Tp,Tpp,Cp,Cpp,Tinf,Cinf,grid.dr,p)[1]
    lo=max(min(Cinf,Cp,Cpp),1e-12)
    hi=max(Cinf,Cp,Cpp)*(1+1e-10)
    xs=np.linspace(lo,hi,256); fs=np.array([f(x) for x in xs])
    brackets=[]
    for j in range(len(xs)-1):
        if fs[j]==0:
            brackets.append((xs[j],xs[j]))
        elif fs[j]*fs[j+1]<0:
            brackets.append((xs[j],xs[j+1]))
    if not brackets:
        raise RuntimeError("reference surface root not bracketed")
    a,b=brackets[-1]
    root=float(a if a==b else brentq(f,a,b,xtol=max(cfg.surface_tol_C,1e-14),rtol=1e-12))
    Ts,_=surface_map_ref(root,Tp,Tpp,Cp,Cpp,Tinf,Cinf,grid.dr,p)
    return float(Ts),root,cfg.surface_max_iter


def rhs_ref(t,y,grid,env,p,cfg):
    N=grid.N; T=y[:N]; C=y[N:]
    kf=k_faces4(C,cfg.face_average)
    Df=D_faces4(C,T,cfg.face_average)
    q=np.zeros(N+1); J=np.zeros(N+1)
    q[1:N]=-kf*np.diff(T)/grid.dr
    J[1:N]=-Df*np.diff(C)/grid.dr
    Ts,Cs,_=surface_ref(T,C,t,grid,env,p,cfg)
    q[N]=p.h*(Ts-float(env.T_inf(t)))
    J[N]=p.hm*(Cs-float(env.C_inf(t)))
    netq=(grid.area[:-1]*q[:-1]-grid.area[1:]*q[1:])/grid.volume
    netJ=(grid.area[:-1]*J[:-1]-grid.area[1:]*J[1:])/grid.volume
    cap=density4(C)*heat_capacity4(C)
    return np.concatenate([netq/cap,netJ])


def cmax_ref(t,y,grid,env,p,cfg):
    N=grid.N; T=y[:N]; C=y[N:]
    C0=center_reconstruction(C)
    _,Cs,_=surface_ref(T,C,t,grid,env,p,cfg)
    vals=np.concatenate([[C0],C,[Cs]])
    rs=np.concatenate([[0.0],grid.centers,[grid.R]])
    j=int(np.argmax(vals))
    return float(vals[j]),float(rs[j])


def segmented_trajectory(rhs_builder,y0,t_end=14400.0,dt_out=300.0,rtol=1e-9,atol=1e-11,max_step=30.0):
    """End-to-end BDF trajectory without artificial 60-s solver restarts."""
    nstate=len(y0)
    N=nstate//2
    times=np.arange(0.0,t_end+0.5*dt_out,dt_out)
    s=solve_ivp(
        rhs_builder,(0.0,t_end),y0,method="BDF",t_eval=times,
        rtol=rtol,atol=atol,max_step=max_step,
        jac_sparsity=jacobian_sparsity(N),
    )
    if not s.success:
        raise RuntimeError(s.message)
    return np.asarray(s.t),np.asarray(s.y.T)


def find_event(rhs,event,y0,max_time,rtol=2e-8,atol=2e-10,max_step=900.0):
    event.terminal=True; event.direction=-1.0
    N=len(y0)//2
    s=solve_ivp(
        rhs,(0,max_time),y0,method="BDF",
        rtol=rtol,atol=atol,max_step=max_step,events=event,
        jac_sparsity=jacobian_sparsity(N),
    )
    if not s.success or s.t_events[0].size==0:
        raise RuntimeError("event not reached")
    return float(s.t_events[0][0]),np.asarray(s.y_events[0][0])


def main():
    env_path=ROOT/"data"/"附件1.xlsx"
    env=LongTermEnvironment.from_excel(env_path,"last_hour_mean")
    p=Q4Parameters()
    cfg=Q4Config(
        rtol=2e-10,atol=2e-12,
        max_step_data=5.0,max_step_long=60.0,
        surface_tol_T=1e-12,surface_tol_C=1e-13,
        surface_max_iter=80,
        refine_event=False,
    )
    R0=p.R0
    N=32
    mg=MaterialGrid.build(N)
    pg=PhysicalGrid.build(N,R0)
    cr=ConstantRadius(R0)

    tests=[]

    # 1 geometry
    tests.append(("faces",np.max(np.abs(R0*mg.xi_faces-pg.faces))))
    tests.append(("centers",np.max(np.abs(R0*mg.xi_centers-pg.centers))))
    tests.append(("dr",abs(R0*mg.dxi-pg.dr)))

    # 2 surface algebra for nontrivial fields
    xi=mg.xi_centers
    T=31.0+8.0*xi**2+0.2*np.sin(3*np.pi*xi)
    C=2.3-0.8*xi**2+0.05*np.cos(2*np.pi*xi)
    for tt in [0.0,1234.0,7200.0,14399.0]:
        a=coupled_surface_q4(T,C,tt,mg,cr,env,p,cfg)[:2]
        b=surface_ref(T,C,tt,pg,env,p,cfg)[:2]
        tests.append((f"surface@{tt:g}",max(abs(a[0]-b[0]),abs(a[1]-b[1]))))

    # 3 full RHS for several states/times
    rng=np.random.default_rng(20260911)
    for tt in [0.0,321.0,3599.0,7201.0,14399.0]:
        Tt=T+0.15*rng.standard_normal(N)
        Ct=C+0.015*rng.standard_normal(N)
        y=np.concatenate([Tt,Ct])
        a=q4_rhs(tt,y,mg,cr,env,p,cfg)
        b=rhs_ref(tt,y,pg,env,p,cfg)
        scale=max(np.max(np.abs(b)),1e-30)
        tests.append((f"rhs_rel@{tt:g}",np.max(np.abs(a-b))/scale))

    # 4 exact transformed dry-basis balance at a synthetic state
    y=np.concatenate([T,C])
    dy=q4_rhs(7000.0,y,mg,cr,env,p,cfg)
    _,Cs,_=coupled_surface_q4(T,C,7000.0,mg,cr,env,p,cfg)
    lhs=float(np.sum(mg.volume_weight*dy[N:]))
    rhsbal=-2*p.hm/R0*(Cs-float(env.C_inf(7000.0)))
    tests.append(("dry_basis_balance",abs(lhs-rhsbal)/max(abs(rhsbal),1e-30)))

    # 5 full BDF trajectory over entire measured 0-4 h interval
    y0=np.concatenate([np.full(N,p.T0_C),np.full(N,p.C0)])
    tm,ym=segmented_trajectory(
        lambda t,y:q4_rhs(t,y,mg,cr,env,p,cfg),
        y0,t_end=14400.0,dt_out=300.0,max_step=30.0
    )
    tr,yr=segmented_trajectory(
        lambda t,y:rhs_ref(t,y,pg,env,p,cfg),
        y0,t_end=14400.0,dt_out=300.0,max_step=30.0
    )
    dT=float(np.max(np.abs(ym[:,:N]-yr[:,:N])))
    dC=float(np.max(np.abs(ym[:,N:]-yr[:,N:])))
    tests.append(("trajectory_T_abs",dT))
    tests.append(("trajectory_C_abs",dC))

    # 6 output reconstruction at 4 h
    target=np.linspace(0,R0,21)
    To,Co,_=sample_q4_state(ym[-1,:N],ym[-1,N:],14400.0,target,mg,cr,env,p,cfg)
    T0=center_reconstruction(yr[-1,:N]); C0=center_reconstruction(yr[-1,N:])
    Ts,Cs,_=surface_ref(yr[-1,:N],yr[-1,N:],14400.0,pg,env,p,cfg)
    raug=np.concatenate([[0.0],pg.centers,[R0]])
    Taug=np.concatenate([[T0],yr[-1,:N],[Ts]])
    Caug=np.concatenate([[C0],yr[-1,N:],[Cs]])
    Tr=np.interp(target,raug,Taug); Cr=np.interp(target,raug,Caug)
    tests.append(("output_T_abs",float(np.max(np.abs(To-Tr)))))
    tests.append(("output_C_abs",float(np.max(np.abs(Co-Cr)))))

    # 7 terminal-event functional degeneration near the threshold.
    # This checks exactly what Q3/Q4 event detection sees without spending
    # tens/hundreds of physical hours integrating a fixed-radius Appendix-4 model.
    event_value_err = 0.0
    event_loc_err = 0.0
    for baseC in [0.18, 0.155, 0.1505, 0.1495]:
        Cn = baseC + 0.01*(1.0-xi**2)  # center is the wettest point
        Tn = np.full(N, 49.9) - 0.1*xi**2
        yn = np.concatenate([Tn,Cn])
        cm, xim, rm = augmented_cmax_q4(20000.0,yn,mg,cr,env,p,cfg)
        crf, rrf = cmax_ref(20000.0,yn,pg,env,p,cfg)
        event_value_err = max(event_value_err, abs((cm-p.threshold)-(crf-p.threshold)))
        event_loc_err = max(event_loc_err, abs(rm-rrf))
    tests.append(("event_value_abs",event_value_err))
    tests.append(("event_location_abs_m",event_loc_err))

    print("FULL FIXED-RADIUS DEGENERATION TEST")
    print("="*72)
    for name,err in tests:
        print(f"{name:30s} {err:.6e}")
    print("-"*72)

    # Conservative pass criteria.
    criteria={
        "faces":1e-15,"centers":1e-15,"dr":1e-15,
        "surface@0":1e-11,"surface@1234":1e-11,"surface@7200":1e-11,"surface@14399":1e-11,
        "rhs_rel@0":1e-11,"rhs_rel@321":1e-11,"rhs_rel@3599":1e-11,"rhs_rel@7201":1e-11,"rhs_rel@14399":1e-11,
        "dry_basis_balance":1e-11,
        "trajectory_T_abs":5e-6,"trajectory_C_abs":1e-8,
        "output_T_abs":5e-7,"output_C_abs":1e-9,
        "event_value_abs":1e-12,"event_location_abs_m":1e-14,
    }
    failed=[]
    for name,err in tests:
        # Normalize test names for the exact-time surface labels.
        key=name
        tol=criteria.get(key,1e-10)
        if err>tol:
            failed.append((name,err,tol))
    passed=not failed
    print("PASS:",passed)
    if failed:
        print("Failures:",failed)
        raise SystemExit(1)


if __name__=="__main__":
    main()
