from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Literal, Optional, Sequence
import math

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp, cumulative_trapezoid
from scipy.optimize import brentq
from scipy.interpolate import PchipInterpolator
from openpyxl import Workbook, load_workbook

from q3_solver import LongTermEnvironment
from q2_solver import jacobian_sparsity
from q4_geometry_core import RadiusHistory, ConstantRadius, MaterialGrid

Array = np.ndarray
FaceAverage = Literal["harmonic", "arithmetic", "midpoint_property"]
RadiusMode = Literal["linear", "pchip"]


@dataclass(frozen=True)
class Q4Parameters:
    R0: float = 0.02
    T0_C: float = 28.0
    C0: float = 2.55
    h: float = 25.0
    hm: float = 8.0e-7
    threshold: float = 0.15


@dataclass(frozen=True)
class Q4Config:
    method: str = "BDF"
    rtol: float = 1.0e-9
    atol: float = 1.0e-11

    max_step_data: float = 5.0
    max_step_long: float = 60.0
    event_max_step: float = 5.0
    event_rtol: float = 2.0e-10
    event_atol: float = 2.0e-12
    event_refine_window_s: float = 300.0
    refine_event: bool = True

    output_dt: float = 60.0
    output_fixed_dr: float = 0.001  # 0.1 cm
    long_segment_s: float = 3600.0

    face_average: FaceAverage = "harmonic"
    segment_at_environment_knots: bool = True
    segment_at_radius_knots: bool = True

    surface_tol_T: float = 1.0e-11
    surface_tol_C: float = 1.0e-12
    surface_max_iter: int = 50
    surface_relaxation: float = 1.0

    max_time_s: float = 15.0 * 24.0 * 3600.0


@dataclass(frozen=True)
class PchipRadiusHistory:
    t_data: Array
    R_data: Array
    _pchip: PchipInterpolator

    @classmethod
    def from_excel(cls, path: str | Path) -> "PchipRadiusHistory":
        linear = RadiusHistory.from_excel(path)
        p = PchipInterpolator(linear.t_data, linear.R_data, extrapolate=False)
        return cls(linear.t_data.copy(), linear.R_data.copy(), p)

    @property
    def t_end(self) -> float:
        return float(self.t_data[-1])

    @property
    def R0(self) -> float:
        return float(self.R_data[0])

    @property
    def R_end(self) -> float:
        return float(self.R_data[-1])

    def radius(self, t: float | Array) -> float | Array:
        x = np.asarray(t, dtype=float)
        if np.any(x < self.t_data[0] - 1e-12):
            raise ValueError("Radius history is undefined before t=0.")
        xc = np.minimum(x, self.t_end)
        y = np.asarray(self._pchip(xc), dtype=float)
        y = np.where(x >= self.t_end, self.R_end, y)
        if np.ndim(t) == 0:
            return float(y)
        return y

    def dRdt(self, t: float | Array, knot_side: str = "average") -> float | Array:
        x = np.asarray(t, dtype=float)
        xc = np.minimum(x, self.t_end)
        y = np.asarray(self._pchip.derivative()(xc), dtype=float)
        y = np.where(x >= self.t_end, 0.0, y)
        if np.ndim(t) == 0:
            return float(y)
        return y


# ---------------------------------------------------------------------------
# Appendix-4 material properties
# ---------------------------------------------------------------------------

def density4(C: Array | float) -> Array:
    C = np.asarray(C, dtype=float)
    return 760.0 + 90.0 * C


def heat_capacity4(C: Array | float) -> Array:
    C = np.asarray(C, dtype=float)
    return 1850.0 + 2150.0 * C / (C + 1.0)


def thermal_conductivity4(C: Array | float) -> Array:
    C = np.asarray(C, dtype=float)
    return 0.12 + 0.20 * C / (C + 1.0)


def moisture_diffusivity4(C: Array | float, T_C: Array | float) -> Array:
    C = np.asarray(C, dtype=float)
    T_C = np.asarray(T_C, dtype=float)
    if np.any(C <= 0.0):
        raise FloatingPointError("Appendix-4 D(C,T) requires C > 0.")
    TK = T_C + 273.15
    if np.any(TK <= 0.0):
        raise FloatingPointError("Absolute temperature must remain positive.")
    return 4.2e-4 * np.exp(-0.30 / C) * np.exp(-3850.0 / TK)


def check_q4_state(T_C: Array, C: Array) -> None:
    if not np.all(np.isfinite(T_C)) or not np.all(np.isfinite(C)):
        raise FloatingPointError("Non-finite Q4 state.")
    if np.any(C <= 0.0):
        raise FloatingPointError("Q4 moisture must remain positive.")
    for arr, name in [
        (density4(C), "rho"),
        (heat_capacity4(C), "cp"),
        (thermal_conductivity4(C), "k"),
        (moisture_diffusivity4(C, T_C), "D"),
    ]:
        if not np.all(np.isfinite(arr)) or np.any(arr <= 0.0):
            raise FloatingPointError(f"Invalid Appendix-4 property {name}.")


# ---------------------------------------------------------------------------
# Face coefficients
# ---------------------------------------------------------------------------

def _harmonic(a: Array, b: Array) -> Array:
    return 2.0 * a * b / (a + b)


def k_faces4(C: Array, method: FaceAverage = "harmonic") -> Array:
    k = thermal_conductivity4(C)
    if method == "harmonic":
        return _harmonic(k[:-1], k[1:])
    if method == "arithmetic":
        return 0.5 * (k[:-1] + k[1:])
    if method == "midpoint_property":
        return thermal_conductivity4(0.5 * (C[:-1] + C[1:]))
    raise ValueError(f"Unknown face-average method: {method}")


def D_faces4(C: Array, T_C: Array, method: FaceAverage = "harmonic") -> Array:
    D = moisture_diffusivity4(C, T_C)
    if method == "harmonic":
        return _harmonic(D[:-1], D[1:])
    if method == "arithmetic":
        return 0.5 * (D[:-1] + D[1:])
    if method == "midpoint_property":
        return moisture_diffusivity4(
            0.5 * (C[:-1] + C[1:]),
            0.5 * (T_C[:-1] + T_C[1:]),
        )
    raise ValueError(f"Unknown face-average method: {method}")


# ---------------------------------------------------------------------------
# Local coupled moving-R Robin solve in material coordinates
# ---------------------------------------------------------------------------

def _surface_map_q4(
    Cs: float,
    Tp: float,
    Tpp: float,
    Cp: float,
    Cpp: float,
    Tinf: float,
    Cinf: float,
    R: float,
    dxi: float,
    p: Q4Parameters,
) -> tuple[float, float]:
    # dr at the surface reconstruction equals R*dxi.
    ds = R * dxi
    ks = float(thermal_conductivity4(Cs))
    Ts = (ks * (9.0 * Tp - Tpp) + 3.0 * ds * p.h * Tinf) / (
        8.0 * ks + 3.0 * ds * p.h
    )
    Ds = float(moisture_diffusivity4(Cs, Ts))
    Cs_raw = (Ds * (9.0 * Cp - Cpp) + 3.0 * ds * p.hm * Cinf) / (
        8.0 * Ds + 3.0 * ds * p.hm
    )
    return float(Ts), float(Cs_raw)


def coupled_surface_q4(
    T: Array,
    C: Array,
    t: float,
    grid: MaterialGrid,
    radius_law,
    env: LongTermEnvironment,
    p: Q4Parameters,
    cfg: Q4Config,
    counter: Optional[dict] = None,
) -> tuple[float, float, int]:
    if len(T) < 2:
        raise ValueError("At least two cells are required.")
    R = float(radius_law.radius(t))
    Tp, Tpp = float(T[-1]), float(T[-2])
    Cp, Cpp = float(C[-1]), float(C[-2])
    Tinf = float(env.T_inf(t))
    Cinf = float(env.C_inf(t))

    omega = float(cfg.surface_relaxation)
    if not (0.0 < omega <= 1.0):
        raise ValueError("surface_relaxation must lie in (0,1].")

    Cs = max(Cp, 1e-12)
    Ts, _ = _surface_map_q4(Cs, Tp, Tpp, Cp, Cpp, Tinf, Cinf, R, grid.dxi, p)
    prev_delta = None
    dyn_omega = omega

    for it in range(1, cfg.surface_max_iter + 1):
        _, raw = _surface_map_q4(Cs, Tp, Tpp, Cp, Cpp, Tinf, Cinf, R, grid.dxi, p)
        delta = raw - Cs
        if prev_delta is not None and delta * prev_delta < 0.0 and abs(delta) > 0.8*abs(prev_delta):
            dyn_omega = max(0.15, 0.5 * dyn_omega)
        Cs_new = dyn_omega * raw + (1.0 - dyn_omega) * Cs
        Ts_new, _ = _surface_map_q4(
            Cs_new, Tp, Tpp, Cp, Cpp, Tinf, Cinf, R, grid.dxi, p
        )
        if Cs_new <= 0.0 or not (math.isfinite(Ts_new) and math.isfinite(Cs_new)):
            raise FloatingPointError("Invalid Q4 surface Picard state.")
        if abs(Ts_new-Ts) <= cfg.surface_tol_T and abs(Cs_new-Cs) <= cfg.surface_tol_C:
            if counter is not None:
                counter["picard_success"] = counter.get("picard_success", 0) + 1
            return float(Ts_new), float(Cs_new), it
        prev_delta = delta
        Ts, Cs = Ts_new, Cs_new

    # Same algebraic Robin equation, robustly select the largest root connected
    # to the near-surface interior state. This is a safety fallback only.
    def residual(x: float) -> float:
        _, fx = _surface_map_q4(x, Tp, Tpp, Cp, Cpp, Tinf, Cinf, R, grid.dxi, p)
        return x - fx

    lo = max(min(Cinf, Cp, Cpp), 1e-12)
    hi = max(Cp, Cpp, Cinf) * (1.0 + 1e-10)
    if hi <= lo:
        hi = lo + max(1e-8, 1e-6*abs(lo))
    xs = np.linspace(lo, hi, 256)
    fs = np.array([residual(float(x)) for x in xs])
    brackets = []
    for j in range(len(xs)-1):
        if fs[j] == 0.0:
            brackets.append((float(xs[j]), float(xs[j])))
        elif fs[j] * fs[j+1] < 0.0:
            brackets.append((float(xs[j]), float(xs[j+1])))
    if fs[-1] == 0.0:
        brackets.append((float(xs[-1]), float(xs[-1])))
    if not brackets:
        raise RuntimeError(
            f"Q4 surface Picard failed and no physical continuation-root bracket "
            f"was found at t={t:.6g}s."
        )
    a, b = brackets[-1]
    root = a if a == b else float(brentq(
        residual, a, b,
        xtol=max(cfg.surface_tol_C, 1e-14), rtol=1e-12, maxiter=100
    ))
    Ts, _ = _surface_map_q4(root, Tp, Tpp, Cp, Cpp, Tinf, Cinf, R, grid.dxi, p)
    if counter is not None:
        counter["brent_fallback"] = counter.get("brent_fallback", 0) + 1
    return float(Ts), float(root), cfg.surface_max_iter


# ---------------------------------------------------------------------------
# Q4 mapped RHS
# ---------------------------------------------------------------------------

def q4_rhs(
    t: float,
    y: Array,
    grid: MaterialGrid,
    radius_law,
    env: LongTermEnvironment,
    p: Q4Parameters,
    cfg: Q4Config,
    surface_counter: Optional[dict] = None,
) -> Array:
    N = grid.N
    T = np.asarray(y[:N], dtype=float)
    C = np.asarray(y[N:], dtype=float)
    check_q4_state(T, C)

    R = float(radius_law.radius(t))
    kf = k_faces4(C, cfg.face_average)
    Df = D_faces4(C, T, cfg.face_average)

    # Fluxes with respect to xi: q_xi=-k*T_xi, J_xi=-D*C_xi.
    qxi = np.zeros(N+1)
    Jxi = np.zeros(N+1)
    qxi[1:N] = -kf * (T[1:] - T[:-1]) / grid.dxi
    Jxi[1:N] = -Df * (C[1:] - C[:-1]) / grid.dxi

    local = {}
    Ts, Cs, nit = coupled_surface_q4(
        T, C, t, grid, radius_law, env, p, cfg, local
    )
    # Robin is a physical-r flux. Since q_xi=R*q_r:
    qxi[N] = R * p.h * (Ts - float(env.T_inf(t)))
    Jxi[N] = R * p.hm * (Cs - float(env.C_inf(t)))

    if surface_counter is not None:
        surface_counter["calls"] = surface_counter.get("calls", 0) + 1
        surface_counter["iterations"] = surface_counter.get("iterations", 0) + nit
        surface_counter["max_iterations"] = max(
            surface_counter.get("max_iterations", 0), nit
        )
        surface_counter["picard_success"] = (
            surface_counter.get("picard_success", 0) + local.get("picard_success", 0)
        )
        surface_counter["brent_fallback"] = (
            surface_counter.get("brent_fallback", 0) + local.get("brent_fallback", 0)
        )

    netq = (
        grid.area_weight[:-1] * qxi[:-1]
        - grid.area_weight[1:] * qxi[1:]
    ) / (R*R * grid.volume_weight)
    netJ = (
        grid.area_weight[:-1] * Jxi[:-1]
        - grid.area_weight[1:] * Jxi[1:]
    ) / (R*R * grid.volume_weight)

    cap = density4(C) * heat_capacity4(C)
    return np.concatenate([netq/cap, netJ])


def center_reconstruction(u: Array) -> float:
    return float((9.0*u[0]-u[1])/8.0)


def augmented_cmax_q4(
    t: float,
    y: Array,
    grid: MaterialGrid,
    radius_law,
    env: LongTermEnvironment,
    p: Q4Parameters,
    cfg: Q4Config,
) -> tuple[float, float, float]:
    N = grid.N
    T, C = y[:N], y[N:]
    C0 = center_reconstruction(C)
    _, Cs, _ = coupled_surface_q4(T, C, t, grid, radius_law, env, p, cfg)
    vals = np.concatenate([[C0], C, [Cs]])
    xis = np.concatenate([[0.0], grid.xi_centers, [1.0]])
    j = int(np.argmax(vals))
    xi = float(xis[j])
    R = float(radius_law.radius(t))
    return float(vals[j]), xi, xi*R


def make_q4_event(grid, radius_law, env, p, cfg):
    def event(t, y):
        return augmented_cmax_q4(t, y, grid, radius_law, env, p, cfg)[0] - p.threshold
    event.terminal = True
    event.direction = -1.0
    return event


def sample_q4_state(
    T: Array,
    C: Array,
    t: float,
    physical_r: Array,
    grid: MaterialGrid,
    radius_law,
    env: LongTermEnvironment,
    p: Q4Parameters,
    cfg: Q4Config,
) -> tuple[Array, Array, Array]:
    """Sample fixed physical radii. Points outside the current solid are NaN."""
    physical_r = np.asarray(physical_r, dtype=float)
    R = float(radius_law.radius(t))
    T0, C0 = center_reconstruction(T), center_reconstruction(C)
    if abs(t) <= 1e-14:
        Ts, Cs = p.T0_C, p.C0
    else:
        Ts, Cs, _ = coupled_surface_q4(T, C, t, grid, radius_law, env, p, cfg)

    xi_aug = np.concatenate([[0.0], grid.xi_centers, [1.0]])
    T_aug = np.concatenate([[T0], T, [Ts]])
    C_aug = np.concatenate([[C0], C, [Cs]])

    Tout = np.full(physical_r.shape, np.nan)
    Cout = np.full(physical_r.shape, np.nan)
    inside = physical_r <= R + 1e-12
    xi = physical_r[inside] / R
    Tout[inside] = np.interp(xi, xi_aug, T_aug)
    Cout[inside] = np.interp(xi, xi_aug, C_aug)
    return Tout, Cout, inside


# ---------------------------------------------------------------------------
# Segment construction and long-time production solve
# ---------------------------------------------------------------------------

def build_radius_law(path: str | Path, mode: RadiusMode = "linear"):
    if mode == "linear":
        return RadiusHistory.from_excel(path)
    if mode == "pchip":
        return PchipRadiusHistory.from_excel(path)
    raise ValueError(mode)


def _segment_edges(
    env: LongTermEnvironment,
    radius_law,
    cfg: Q4Config,
) -> Array:
    end = float(cfg.max_time_s)
    edges = {0.0, end}

    # Regime-change endpoints are always segment boundaries.
    if env.data_end_s < end:
        edges.add(float(env.data_end_s))
    if np.isfinite(getattr(radius_law, "t_end", np.inf)) and radius_law.t_end < end:
        edges.add(float(radius_law.t_end))

    if cfg.segment_at_environment_knots:
        for x in env.t:
            x = float(x)
            if 0.0 < x < min(env.data_end_s, end):
                edges.add(x)

    if cfg.segment_at_radius_knots and hasattr(radius_law, "t_data"):
        for x in radius_law.t_data:
            x = float(x)
            if 0.0 < x < min(radius_law.t_end, end):
                edges.add(x)

    last_structured = max(
        [0.0]
        + ([float(env.data_end_s)] if env.data_end_s < end else [])
        + ([float(radius_law.t_end)] if np.isfinite(getattr(radius_law, "t_end", np.inf)) and radius_law.t_end < end else [])
    )
    x = last_structured
    while x < end - 1e-10:
        x = min(end, x + cfg.long_segment_s)
        edges.add(float(x))

    return np.array(sorted(edges), dtype=float)


def _regular_times(a: float, b: float, dt: float, include_left: bool) -> Array:
    n0 = int(math.ceil((a-1e-10)/dt))
    n1 = int(math.floor((b+1e-10)/dt))
    if n1 < n0:
        return np.array([], dtype=float)
    tt = np.arange(n0, n1+1, dtype=float)*dt
    tt = tt[(tt >= a-1e-10) & (tt <= b+1e-10)]
    if not include_left:
        tt = tt[tt > a+1e-10]
    return tt


@dataclass
class Q4Solution:
    grid: MaterialGrid
    radius_law: object
    env: LongTermEnvironment
    params: Q4Parameters
    config: Q4Config
    t: Array
    fixed_r: Array
    T_fixed: Array
    C_fixed: Array
    T_surface: Array
    C_surface: Array
    R_out: Array
    Cbar_out: Array
    state_t: Array
    T_state: Array
    C_state: Array
    t_dry_s: float
    y_dry: Array
    Cmax_dry: float
    xi_max_dry: float
    r_max_dry: float
    solver_stats: dict = field(default_factory=dict)


def _refine_event(ivp, te0, grid, radius_law, env, p, cfg):
    if not cfg.refine_event:
        return float(te0), np.asarray(ivp.y_events[0][0]), {"refined": False}
    left = max(float(ivp.t[0]), float(te0)-cfg.event_refine_window_s)
    right = float(te0)+cfg.event_refine_window_s
    yleft = np.asarray(ivp.sol(left))
    event = make_q4_event(grid, radius_law, env, p, cfg)
    rhs = lambda t,y: q4_rhs(t,y,grid,radius_law,env,p,cfg)
    sparsity = jacobian_sparsity(grid.N) if cfg.method.upper() in {"BDF","RADAU"} else None
    ref = solve_ivp(
        rhs, (left,right), yleft, method=cfg.method,
        rtol=cfg.event_rtol, atol=cfg.event_atol,
        max_step=cfg.event_max_step, events=event,
        jac_sparsity=sparsity,
    )
    if not ref.success or ref.t_events[0].size == 0:
        raise RuntimeError("Q4 local event refinement failed.")
    te = float(ref.t_events[0][0])
    ye = np.asarray(ref.y_events[0][0])
    return te, ye, {
        "refined": True,
        "baseline_event_s": float(te0),
        "refined_event_s": te,
        "refinement_shift_s": te-float(te0),
    }


def solve_q4(
    env_path: str | Path,
    radius_path: str | Path,
    N: int = 640,
    cfg: Optional[Q4Config] = None,
    p: Optional[Q4Parameters] = None,
    radius_mode: RadiusMode = "linear",
    boundary_strategy: str = "last_hour_mean",
    radius_law_override=None,
) -> Q4Solution:
    cfg = cfg or Q4Config()
    p = p or Q4Parameters()
    env = LongTermEnvironment.from_excel(env_path, boundary_strategy)
    radius_law = radius_law_override or build_radius_law(radius_path, radius_mode)
    grid = MaterialGrid.build(N)

    # Fixed physical output columns 0..1.9 cm; surface is stored separately.
    fixed_r = np.arange(0.0, 0.019 + 0.5*cfg.output_fixed_dr, cfg.output_fixed_dr)

    y = np.concatenate([
        np.full(N, p.T0_C),
        np.full(N, p.C0),
    ])
    edges = _segment_edges(env, radius_law, cfg)
    event = make_q4_event(grid, radius_law, env, p, cfg)
    sparsity = jacobian_sparsity(N) if cfg.method.upper() in {"BDF","RADAU"} else None

    t_chunks, T_chunks, C_chunks, Ts_chunks, Cs_chunks, R_chunks, Cbar_chunks = [], [], [], [], [], [], []
    state_t = [0.0]
    T_state = [y[:N].copy()]
    C_state = [y[N:].copy()]
    counter = {}
    stats = {"segments":0,"nfev":0,"njev":0,"nlu":0}
    te = None
    ye = None
    event_meta = {}

    for s,(a,b) in enumerate(zip(edges[:-1], edges[1:])):
        a,b=float(a),float(b)
        tev = _regular_times(a,b,cfg.output_dt,include_left=(s==0))
        max_step = cfg.max_step_data if a < env.data_end_s-1e-12 else cfg.max_step_long
        rhs = lambda t,y: q4_rhs(t,y,grid,radius_law,env,p,cfg,counter)
        ivp = solve_ivp(
            rhs,(a,b),y,method=cfg.method,
            t_eval=tev if tev.size else None,
            rtol=cfg.rtol,atol=cfg.atol,max_step=max_step,
            events=event,dense_output=cfg.refine_event,
            jac_sparsity=sparsity,
        )
        if not ivp.success:
            raise RuntimeError(f"Q4 solve failed on [{a},{b}]: {ivp.message}")
        stats["segments"] += 1
        stats["nfev"] += int(ivp.nfev)
        stats["njev"] += int(getattr(ivp,"njev",0) or 0)
        stats["nlu"] += int(getattr(ivp,"nlu",0) or 0)

        if ivp.t.size:
            st, sT, sC, sTs, sCs, sR, sCb = [], [], [], [], [], [], []
            for j,tt in enumerate(ivp.t):
                Tj=ivp.y[:N,j]; Cj=ivp.y[N:,j]
                To,Co,_ = sample_q4_state(
                    Tj,Cj,float(tt),fixed_r,grid,radius_law,env,p,cfg
                )
                Ts,Cs,_ = coupled_surface_q4(
                    Tj,Cj,float(tt),grid,radius_law,env,p,cfg
                ) if tt > 1e-14 else (p.T0_C,p.C0,0)
                st.append(float(tt)); sT.append(To); sC.append(Co)
                sTs.append(Ts); sCs.append(Cs); sR.append(float(radius_law.radius(tt)))
                sCb.append(float(np.sum(grid.volume_weight*Cj)))
            t_chunks.append(np.array(st))
            T_chunks.append(np.array(sT))
            C_chunks.append(np.array(sC))
            Ts_chunks.append(np.array(sTs))
            Cs_chunks.append(np.array(sCs))
            R_chunks.append(np.array(sR))
            Cbar_chunks.append(np.array(sCb))

        if ivp.t_events and ivp.t_events[0].size:
            te0=float(ivp.t_events[0][0])
            te,ye,event_meta=_refine_event(
                ivp,te0,grid,radius_law,env,p,cfg
            )
            state_t.append(te)
            T_state.append(ye[:N].copy())
            C_state.append(ye[N:].copy())
            break

        y = ivp.y[:,-1].copy()
        state_t.append(b)
        T_state.append(y[:N].copy())
        C_state.append(y[N:].copy())

    if te is None or ye is None:
        cmax,xim,rm=augmented_cmax_q4(
            state_t[-1], np.concatenate([T_state[-1],C_state[-1]]),
            grid,radius_law,env,p,cfg
        )
        raise RuntimeError(
            f"Q4 threshold not reached by {cfg.max_time_s/3600:.3f} h; "
            f"Cmax={cmax:.6g}, xi={xim:.4f}, r={100*rm:.4f} cm."
        )

    t=np.concatenate(t_chunks)
    Tfix=np.vstack(T_chunks)
    Cfix=np.vstack(C_chunks)
    Tsurf=np.concatenate(Ts_chunks)
    Csurf=np.concatenate(Cs_chunks)
    Rout=np.concatenate(R_chunks)
    Cbar=np.concatenate(Cbar_chunks)

    order=np.argsort(t)
    t,Tfix,Cfix,Tsurf,Csurf,Rout,Cbar = (
        t[order],Tfix[order],Cfix[order],Tsurf[order],Csurf[order],Rout[order],Cbar[order]
    )
    _,uidx=np.unique(np.round(t,10),return_index=True)
    uidx=np.sort(uidx)
    t,Tfix,Cfix,Tsurf,Csurf,Rout,Cbar = (
        t[uidx],Tfix[uidx],Cfix[uidx],Tsurf[uidx],Csurf[uidx],Rout[uidx],Cbar[uidx]
    )

    # Keep regular output through the last 60-s time not exceeding the event.
    tlast=cfg.output_dt*math.floor((te+1e-10)/cfg.output_dt)
    keep=t<=tlast+1e-8
    t,Tfix,Cfix,Tsurf,Csurf,Rout,Cbar = (
        t[keep],Tfix[keep],Cfix[keep],Tsurf[keep],Csurf[keep],Rout[keep],Cbar[keep]
    )

    cmax,xim,rm=augmented_cmax_q4(te,ye,grid,radius_law,env,p,cfg)
    stats.update({
        "surface_calls": int(counter.get("calls",0)),
        "surface_mean_iterations": (
            float(counter.get("iterations",0))/max(1,int(counter.get("calls",0)))
        ),
        "surface_max_iterations": int(counter.get("max_iterations",0)),
        "surface_picard_success_calls": int(counter.get("picard_success",0)),
        "surface_brent_fallback_calls": int(counter.get("brent_fallback",0)),
        "radius_mode": radius_mode if radius_law_override is None else type(radius_law_override).__name__,
        **event_meta,
    })

    return Q4Solution(
        grid=grid,radius_law=radius_law,env=env,params=p,config=cfg,
        t=t,fixed_r=fixed_r,T_fixed=Tfix,C_fixed=Cfix,
        T_surface=Tsurf,C_surface=Csurf,R_out=Rout,Cbar_out=Cbar,
        state_t=np.array(state_t),T_state=np.array(T_state),C_state=np.array(C_state),
        t_dry_s=float(te),y_dry=np.asarray(ye),
        Cmax_dry=float(cmax),xi_max_dry=float(xim),r_max_dry=float(rm),
        solver_stats=stats,
    )


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------

def event_summary(sol: Q4Solution) -> dict:
    return {
        "t_dry_s": sol.t_dry_s,
        "t_dry_h": sol.t_dry_s/3600.0,
        "Cmax": sol.Cmax_dry,
        "g_event": sol.Cmax_dry-sol.params.threshold,
        "xi_max": sol.xi_max_dry,
        "r_max_cm": 100.0*sol.r_max_dry,
        "R_event_cm": 100.0*float(sol.radius_law.radius(sol.t_dry_s)),
        "C_surface": float(
            coupled_surface_q4(
                sol.y_dry[:sol.grid.N], sol.y_dry[sol.grid.N:],
                sol.t_dry_s, sol.grid, sol.radius_law, sol.env, sol.params, sol.config
            )[1]
        ),
    }


def q4_balance_diagnostics(sol: Q4Solution) -> dict:
    """Check transformed semi-discrete heat/moisture balances.

    For dry-basis moisture, with normalized annular weights sum(w_i)=1:
        d(Cbar_d)/dt = -2*hm/R*(Cs-Cinf).
    """
    heat_abs=[]; heat_terms=[]
    moist_abs=[]; moist_terms=[]
    cbar=[]; rhs_bar=[]

    for t,T,C in zip(sol.state_t,sol.T_state,sol.C_state):
        y=np.concatenate([T,C])
        dy=q4_rhs(t,y,sol.grid,sol.radius_law,sol.env,sol.params,sol.config)
        dT=dy[:sol.grid.N]; dC=dy[sol.grid.N:]
        R=float(sol.radius_law.radius(t))
        Ts,Cs,_=coupled_surface_q4(
            T,C,t,sol.grid,sol.radius_law,sol.env,sol.params,sol.config
        )
        cap=density4(C)*heat_capacity4(C)
        S=float(np.sum(cap*sol.grid.volume_weight*dT))
        Q=float((2.0/R)*sol.params.h*(Ts-float(sol.env.T_inf(t))))
        W=float(np.sum(sol.grid.volume_weight*dC))
        B=float((2.0/R)*sol.params.hm*(Cs-float(sol.env.C_inf(t))))
        heat_abs.append(abs(S+Q)); heat_terms.append(max(abs(S),abs(Q)))
        moist_abs.append(abs(W+B)); moist_terms.append(max(abs(W),abs(B)))
        cbar.append(float(np.sum(sol.grid.volume_weight*C)))
        rhs_bar.append(-B)

    heat_scale=max(max(heat_terms),1e-30)
    moist_scale=max(max(moist_terms),1e-30)

    # Independent cumulative dry-basis balance on the regular output grid.
    Bout = -(2.0*sol.params.hm/sol.R_out) * (
        sol.C_surface - np.asarray(sol.env.C_inf(sol.t), dtype=float)
    )
    pred = sol.Cbar_out[0] + cumulative_trapezoid(Bout, sol.t, initial=0.0)
    resid = sol.Cbar_out - pred
    scale_int = max(
        abs(sol.Cbar_out[0]-sol.Cbar_out[-1]),
        abs(pred[-1]-pred[0]),
        1e-30,
    )

    return {
        "heat_global_normalized_max": max(heat_abs)/heat_scale,
        "moisture_global_normalized_max": max(moist_abs)/moist_scale,
        "moisture_integral_final_relative": abs(resid[-1])/scale_int,
        "moisture_integral_global_normalized_max": np.max(np.abs(resid))/scale_int,
        "state_time_s": np.asarray(sol.state_t),
        "dry_basis_mean_C": np.asarray(cbar),
        "dry_basis_mean_rhs": np.asarray(rhs_bar),
        "regular_time_s": sol.t,
        "regular_Cbar": sol.Cbar_out,
        "regular_integral_residual": resid,
    }


def paper_table6(sol: Q4Solution) -> pd.DataFrame:
    fixed = np.array([0.0,0.005,0.010])
    rows=[]; labels=[]
    scheduled=np.arange(6*3600.0,sol.t_dry_s-1e-8,6*3600.0)
    for tt in scheduled:
        j=int(np.argmin(np.abs(sol.t-tt)))
        if abs(sol.t[j]-tt)>1e-8:
            raise RuntimeError(f"Missing scheduled output at {tt}s.")
        vals=[]
        for rr in fixed:
            k=int(np.argmin(np.abs(sol.fixed_r-rr)))
            vals.append(sol.C_fixed[j,k] if abs(sol.fixed_r[k]-rr)<1e-12 else np.nan)
        vals.append(sol.C_surface[j])
        rows.append(vals); labels.append(f"{tt/3600:.0f}")

    T=sol.y_dry[:sol.grid.N]; C=sol.y_dry[sol.grid.N:]
    _,Ce,_=sample_q4_state(
        T,C,sol.t_dry_s,fixed,sol.grid,sol.radius_law,sol.env,sol.params,sol.config
    )
    _,Cs,_=coupled_surface_q4(
        T,C,sol.t_dry_s,sol.grid,sol.radius_law,sol.env,sol.params,sol.config
    )
    rows.append([*Ce,float(Cs)])
    labels.append(f"Dry end ({sol.t_dry_s/3600:.6f} h)")
    df=pd.DataFrame(rows,index=labels,columns=["0 cm","0.5 cm","1.0 cm","Surface"])
    df.index.name="Time (h)"
    return df


def write_result4(
    sol: Q4Solution,
    output_path: str | Path,
    template_path: Optional[str | Path]=None,
    decimals: int=4,
) -> Path:
    output_path=Path(output_path)
    output_path.parent.mkdir(parents=True,exist_ok=True)
    if template_path is not None:
        wb=load_workbook(template_path)
        ws=wb.active
    else:
        wb=Workbook()
        ws=wb.active
        ws.title="Sheet1"

    # Generic layout matching the described official template semantics.
    ws.cell(1,1,"时间\\到药材中心的距离")
    for j,r in enumerate(sol.fixed_r,start=2):
        ws.cell(1,j,round(float(r*100.0),10))
    surface_col=2+len(sol.fixed_r)
    ws.cell(1,surface_col,"药材表面")

    # Q4 result template starts at 60 s, not 0 s.
    rows=np.where(sol.t>=60.0-1e-8)[0]
    for ii,j in enumerate(rows,start=2):
        ws.cell(ii,1,int(round(float(sol.t[j]))))
        for k in range(len(sol.fixed_r)):
            val=sol.C_fixed[j,k]
            ws.cell(ii,k+2,None if not np.isfinite(val) else round(float(val),decimals))
        ws.cell(ii,surface_col,round(float(sol.C_surface[j]),decimals))

    wb.save(output_path)
    return output_path


@dataclass(frozen=True)
class Q4DryingTime:
    N: int
    t_dry_s: float
    t_dry_h: float
    Cmax: float
    xi_max: float
    r_max_cm: float
    R_event_cm: float
    solver_stats: dict


def find_q4_drying_time(
    env_path: str | Path,
    radius_path: str | Path,
    N: int = 320,
    cfg: Optional[Q4Config] = None,
    p: Optional[Q4Parameters] = None,
    radius_mode: RadiusMode = "linear",
    boundary_strategy: str = "last_hour_mean",
    radius_law_override=None,
) -> Q4DryingTime:
    """Lightweight Q4 event search for convergence/sensitivity studies."""
    cfg = cfg or Q4Config()
    p = p or Q4Parameters()
    env = LongTermEnvironment.from_excel(env_path,boundary_strategy)
    radius_law = radius_law_override or build_radius_law(radius_path,radius_mode)
    grid = MaterialGrid.build(N)
    event = make_q4_event(grid,radius_law,env,p,cfg)
    sparsity = jacobian_sparsity(N) if cfg.method.upper() in {"BDF","RADAU"} else None

    y=np.concatenate([np.full(N,p.T0_C),np.full(N,p.C0)])
    edges=_segment_edges(env,radius_law,cfg)
    counter={}; stats={"segments":0,"nfev":0,"njev":0,"nlu":0}

    for a,b in zip(edges[:-1],edges[1:]):
        a,b=float(a),float(b)
        max_step=cfg.max_step_data if a < env.data_end_s-1e-12 else cfg.max_step_long
        rhs=lambda t,y:q4_rhs(t,y,grid,radius_law,env,p,cfg,counter)
        s=solve_ivp(
            rhs,(a,b),y,method=cfg.method,
            rtol=cfg.rtol,atol=cfg.atol,max_step=max_step,
            events=event,dense_output=cfg.refine_event,
            jac_sparsity=sparsity,
        )
        if not s.success:
            raise RuntimeError(f"Q4 event search failed on [{a},{b}]: {s.message}")
        stats["segments"]+=1
        stats["nfev"]+=int(s.nfev)
        stats["njev"]+=int(getattr(s,"njev",0) or 0)
        stats["nlu"]+=int(getattr(s,"nlu",0) or 0)

        if s.t_events and s.t_events[0].size:
            te0=float(s.t_events[0][0])
            te,ye,meta=_refine_event(s,te0,grid,radius_law,env,p,cfg)
            cmax,xim,rm=augmented_cmax_q4(te,ye,grid,radius_law,env,p,cfg)
            stats.update({
                "surface_calls":int(counter.get("calls",0)),
                "surface_mean_iterations":float(counter.get("iterations",0))/max(1,int(counter.get("calls",0))),
                "surface_max_iterations":int(counter.get("max_iterations",0)),
                "surface_brent_fallback_calls":int(counter.get("brent_fallback",0)),
                **meta,
            })
            return Q4DryingTime(
                N=N,t_dry_s=te,t_dry_h=te/3600.0,
                Cmax=cmax,xi_max=xim,r_max_cm=100*rm,
                R_event_cm=100*float(radius_law.radius(te)),
                solver_stats=stats,
            )
        y=s.y[:,-1].copy()

    cmax,xim,rm=augmented_cmax_q4(edges[-1],y,grid,radius_law,env,p,cfg)
    raise RuntimeError(
        f"No Q4 drying event by {cfg.max_time_s/3600:.3f} h; "
        f"Cmax={cmax:.6g}, xi={xim:.4f}, r={100*rm:.4f} cm."
    )


def q4_grid_convergence(
    env_path: str | Path,
    radius_path: str | Path,
    N_values: Sequence[int]=(320,640,1280),
    cfg: Optional[Q4Config]=None,
    radius_mode: RadiusMode="linear",
) -> tuple[pd.DataFrame,dict[int,Q4DryingTime]]:
    cfg=cfg or Q4Config()
    results={}
    for N in N_values:
        results[int(N)]=find_q4_drying_time(
            env_path,radius_path,N=int(N),cfg=cfg,radius_mode=radius_mode
        )
    rows=[]
    for a,b in zip(N_values[:-1],N_values[1:]):
        ra,rb=results[int(a)],results[int(b)]
        rows.append({
            "coarse_N":int(a),"fine_N":int(b),
            "tdry_coarse_h":ra.t_dry_h,"tdry_fine_h":rb.t_dry_h,
            "abs_difference_s":abs(rb.t_dry_s-ra.t_dry_s),
            "abs_difference_min":abs(rb.t_dry_s-ra.t_dry_s)/60.0,
        })
    return pd.DataFrame(rows),results


def q4_time_sensitivity(
    env_path: str | Path,
    radius_path: str | Path,
    N: int=320,
    baseline: Optional[Q4Config]=None,
) -> pd.DataFrame:
    baseline=baseline or Q4Config()
    tighter=replace(
        baseline,
        rtol=min(baseline.rtol,2e-10),
        atol=min(baseline.atol,2e-12),
        max_step_long=min(baseline.max_step_long,15.0),
        event_max_step=min(baseline.event_max_step,2.0),
    )
    a=find_q4_drying_time(env_path,radius_path,N=N,cfg=baseline)
    b=find_q4_drying_time(env_path,radius_path,N=N,cfg=tighter)
    return pd.DataFrame([
        {"case":"baseline","tdry_s":a.t_dry_s,"tdry_h":a.t_dry_h},
        {"case":"tighter","tdry_s":b.t_dry_s,"tdry_h":b.t_dry_h},
        {"case":"difference","tdry_s":abs(a.t_dry_s-b.t_dry_s),
         "tdry_h":abs(a.t_dry_s-b.t_dry_s)/3600.0},
    ])


def q4_radius_interpolation_sensitivity(
    env_path: str | Path,
    radius_path: str | Path,
    N: int=320,
    cfg: Optional[Q4Config]=None,
) -> pd.DataFrame:
    cfg=cfg or Q4Config()
    rows=[]
    for mode in ["linear","pchip"]:
        r=find_q4_drying_time(env_path,radius_path,N=N,cfg=cfg,radius_mode=mode)
        rows.append({
            "radius_mode":mode,"tdry_s":r.t_dry_s,"tdry_h":r.t_dry_h,
            "R_event_cm":r.R_event_cm,
        })
    df=pd.DataFrame(rows)
    ref=float(df.loc[df["radius_mode"]=="linear","tdry_s"].iloc[0])
    df["difference_vs_linear_s"]=df["tdry_s"]-ref
    return df


def q4_fixed_vs_shrink(
    env_path: str | Path,
    radius_path: str | Path,
    N: int=320,
    cfg: Optional[Q4Config]=None,
) -> pd.DataFrame:
    """Controlled Appendix-4 geometry effect: fixed R0 vs measured R(t)."""
    cfg=cfg or Q4Config()
    p=Q4Parameters()
    fixed=find_q4_drying_time(
        env_path,radius_path,N=N,cfg=cfg,p=p,
        radius_law_override=ConstantRadius(p.R0)
    )
    shrink=find_q4_drying_time(
        env_path,radius_path,N=N,cfg=cfg,p=p,radius_mode="linear"
    )
    return pd.DataFrame([
        {"model":"Appendix4_fixed_R","tdry_s":fixed.t_dry_s,"tdry_h":fixed.t_dry_h,
         "R_event_cm":fixed.R_event_cm},
        {"model":"Appendix4_shrink_Rt","tdry_s":shrink.t_dry_s,"tdry_h":shrink.t_dry_h,
         "R_event_cm":shrink.R_event_cm},
        {"model":"shrink_effect","tdry_s":shrink.t_dry_s-fixed.t_dry_s,
         "tdry_h":(shrink.t_dry_s-fixed.t_dry_s)/3600.0,
         "R_event_cm":np.nan},
    ])


def physical_diagnostics_q4(sol: Q4Solution) -> dict:
    """Basic Q4 physical/output diagnostics."""
    finite = np.isfinite(sol.C_fixed)
    # At a fixed physical radius, data stop when that location leaves the solid.
    time_nonincrease = []
    for j in range(sol.C_fixed.shape[1]):
        vals = sol.C_fixed[:,j]
        vals = vals[np.isfinite(vals)]
        if len(vals) >= 2:
            time_nonincrease.append(bool(np.all(np.diff(vals) <= 1e-8)))

    # Material-state max location at saved segment endpoints.
    xi_hist=[]; cmax_hist=[]
    for t,T,C in zip(sol.state_t,sol.T_state,sol.C_state):
        cmax,xim,_=augmented_cmax_q4(
            float(t),np.concatenate([T,C]),sol.grid,sol.radius_law,
            sol.env,sol.params,sol.config
        )
        xi_hist.append(xim); cmax_hist.append(cmax)

    expected_inside = sol.fixed_r[None,:] <= sol.R_out[:,None] + 1e-12
    finite_mask = np.isfinite(sol.C_fixed)
    return {
        "all_finite_in_domain": bool(np.all(finite_mask[expected_inside])),
        "all_positive_in_domain": bool(np.all(sol.C_fixed[expected_inside] > 0.0)),
        "outside_positions_are_blank_nan": bool(np.all(~finite_mask[~expected_inside])),
        "domain_mask_matches_radius": bool(np.array_equal(finite_mask, expected_inside)),
        "fixed_radius_time_nonincrease_fraction": float(np.mean(time_nonincrease)) if time_nonincrease else np.nan,
        "Cmax_state_nonincreasing": bool(np.all(np.diff(cmax_hist) <= 1e-8)),
        "xi_max_center_fraction": float(np.mean(np.isclose(xi_hist,0.0,atol=1e-12,rtol=0))),
        "R_initial_cm": 100.0*float(sol.radius_law.radius(0.0)),
        "R_event_cm": 100.0*float(sol.radius_law.radius(sol.t_dry_s)),
        "surface_picard_mean_iterations": sol.solver_stats.get("surface_mean_iterations"),
        "surface_picard_max_iterations": sol.solver_stats.get("surface_max_iterations"),
        "surface_brent_fallback_calls": sol.solver_stats.get("surface_brent_fallback_calls"),
    }


def _cli():
    import argparse
    ap=argparse.ArgumentParser(
        description="Q4 moving-radius drying solver (Appendix-4 properties)"
    )
    ap.add_argument("--env",required=True,help="Attachment 1 xlsx")
    ap.add_argument("--radius",required=True,help="Attachment 2 xlsx")
    ap.add_argument("--output",required=True,help="result4.xlsx output path")
    ap.add_argument("--template",default=None,help="optional official result4 template")
    ap.add_argument("--N",type=int,default=1280)
    ap.add_argument("--radius-mode",choices=["linear","pchip"],default="linear")
    ap.add_argument("--rtol",type=float,default=1e-9)
    ap.add_argument("--atol",type=float,default=1e-11)
    ap.add_argument("--max-step-data",type=float,default=5.0)
    ap.add_argument("--max-step-long",type=float,default=60.0)
    ap.add_argument("--event-max-step",type=float,default=5.0)
    ap.add_argument("--max-time-hours",type=float,default=15*24.0)
    args=ap.parse_args()

    cfg=Q4Config(
        rtol=args.rtol,atol=args.atol,
        max_step_data=args.max_step_data,max_step_long=args.max_step_long,
        event_max_step=args.event_max_step,
        max_time_s=args.max_time_hours*3600.0,
    )
    sol=solve_q4(
        args.env,args.radius,N=args.N,cfg=cfg,radius_mode=args.radius_mode
    )
    print("Event:",event_summary(sol))
    print("Diagnostics:",physical_diagnostics_q4(sol))
    print("Balance:",{
        k:v for k,v in q4_balance_diagnostics(sol).items()
        if np.isscalar(v)
    })
    print(paper_table6(sol).round(4))
    out=write_result4(sol,args.output,template_path=args.template)
    print("Saved:",out)


if __name__=="__main__":
    _cli()
