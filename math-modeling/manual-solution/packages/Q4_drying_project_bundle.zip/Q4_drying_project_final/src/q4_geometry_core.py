from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import numpy as np
from openpyxl import load_workbook

Array = np.ndarray
KnotDerivativeSide = Literal["left", "right", "average"]


@dataclass(frozen=True)
class RadiusHistory:
    """Measured radius history for Q4.

    Units
    -----
    t_data : s
    R_data : m

    Main rule
    ---------
    * piecewise-linear interpolation inside the measured interval;
    * constant final radius after the last measurement;
    * no extrapolation to negative time.

    The final material-coordinate PDE does not require dR/dt explicitly.
    `dRdt` is provided only for diagnostics/material-velocity plots.
    """

    t_data: Array
    R_data: Array

    @classmethod
    def from_excel(
        cls,
        path: str | Path,
        time_column: int = 1,
        radius_column: int = 2,
        radius_unit: Literal["cm", "m"] = "cm",
    ) -> "RadiusHistory":
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb.active

        t_list: list[float] = []
        r_list: list[float] = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            tval = row[time_column - 1] if len(row) >= time_column else None
            rval = row[radius_column - 1] if len(row) >= radius_column else None
            if tval is None or rval is None:
                continue
            t_list.append(float(tval))
            r_list.append(float(rval))

        t = np.asarray(t_list, dtype=float)
        R = np.asarray(r_list, dtype=float)

        if radius_unit == "cm":
            R = R * 1.0e-2
        elif radius_unit != "m":
            raise ValueError("radius_unit must be 'cm' or 'm'.")

        obj = cls(t_data=t, R_data=R)
        obj.validate()
        return obj

    def validate(self) -> None:
        if self.t_data.ndim != 1 or self.R_data.ndim != 1:
            raise ValueError("Radius history arrays must be one-dimensional.")
        if len(self.t_data) < 2 or len(self.t_data) != len(self.R_data):
            raise ValueError("Radius history must contain at least two matched samples.")
        if not np.all(np.isfinite(self.t_data)) or not np.all(np.isfinite(self.R_data)):
            raise ValueError("Radius history contains non-finite values.")
        if not np.all(np.diff(self.t_data) > 0.0):
            raise ValueError("Time samples must be strictly increasing.")
        if np.any(self.R_data <= 0.0):
            raise ValueError("Radius must remain positive.")
        if np.any(np.diff(self.R_data) > 1.0e-12):
            raise ValueError("Q4 radius data are expected to be monotone non-increasing.")
        if self.t_data[0] < -1.0e-12:
            raise ValueError("Radius history cannot start at negative time.")

    @property
    def t_end(self) -> float:
        return float(self.t_data[-1])

    @property
    def R0(self) -> float:
        return float(self.R_data[0])

    @property
    def R_end(self) -> float:
        return float(self.R_data[-1])

    def radius(self, t: float | Array) -> float | Array:
        x = np.asarray(t, dtype=float)
        if np.any(x < self.t_data[0] - 1.0e-12):
            raise ValueError("Q4 radius history is undefined for negative/pre-data time.")

        # np.interp already holds endpoint values outside the data interval.
        y = np.interp(x, self.t_data, self.R_data)
        y = np.where(x >= self.t_end, self.R_end, y)

        if np.ndim(t) == 0:
            return float(y)
        return y

    def dRdt(
        self,
        t: float | Array,
        knot_side: KnotDerivativeSide = "average",
    ) -> float | Array:
        """Derivative of the piecewise-linear radius model.

        At a measurement knot the derivative is mathematically discontinuous.
        This method makes the convention explicit:
        * left: left segment slope;
        * right: right segment slope;
        * average: arithmetic mean of adjacent slopes.

        At t >= t_end, the held-final-radius extension has dR/dt = 0.
        """
        if knot_side not in {"left", "right", "average"}:
            raise ValueError("knot_side must be 'left', 'right', or 'average'.")

        x = np.asarray(t, dtype=float)
        if np.any(x < self.t_data[0] - 1.0e-12):
            raise ValueError("dRdt is undefined for negative/pre-data time.")

        slopes = np.diff(self.R_data) / np.diff(self.t_data)
        out = np.zeros_like(x, dtype=float)
        flat = x.ravel()
        out_flat = out.ravel()

        for j, tj in enumerate(flat):
            if tj >= self.t_end - 1.0e-12:
                out_flat[j] = 0.0
                continue

            # Locate the segment used away from a knot.
            k = int(np.searchsorted(self.t_data, tj, side="right") - 1)
            k = max(0, min(k, len(slopes) - 1))

            # Is tj exactly an interior knot?
            kk = np.where(np.isclose(self.t_data, tj, atol=1e-10, rtol=0.0))[0]
            if kk.size and 0 < int(kk[0]) < len(self.t_data) - 1:
                m = int(kk[0])
                if knot_side == "left":
                    out_flat[j] = slopes[m - 1]
                elif knot_side == "right":
                    out_flat[j] = slopes[m]
                else:
                    out_flat[j] = 0.5 * (slopes[m - 1] + slopes[m])
            else:
                out_flat[j] = slopes[k]

        if np.ndim(t) == 0:
            return float(out)
        return out


@dataclass(frozen=True)
class ConstantRadius:
    """Constant-radius law used for the mandatory Q4 -> Q2/Q3 degeneration test."""

    R0: float

    def __post_init__(self) -> None:
        if not np.isfinite(self.R0) or self.R0 <= 0.0:
            raise ValueError("R0 must be positive and finite.")

    @property
    def t_end(self) -> float:
        return float("inf")

    @property
    def R_end(self) -> float:
        return self.R0

    def radius(self, t: float | Array) -> float | Array:
        x = np.asarray(t, dtype=float)
        if np.any(x < 0.0):
            raise ValueError("Time must be non-negative.")
        y = np.full_like(x, self.R0, dtype=float)
        if np.ndim(t) == 0:
            return float(y)
        return y

    def dRdt(
        self,
        t: float | Array,
        knot_side: KnotDerivativeSide = "average",
    ) -> float | Array:
        x = np.asarray(t, dtype=float)
        if np.any(x < 0.0):
            raise ValueError("Time must be non-negative.")
        y = np.zeros_like(x, dtype=float)
        if np.ndim(t) == 0:
            return float(y)
        return y


@dataclass(frozen=True)
class LinearRadius:
    """Analytic constant-speed radius law for geometry verification."""

    R0: float
    velocity: float  # m/s

    def radius(self, t: float | Array) -> float | Array:
        x = np.asarray(t, dtype=float)
        if np.any(x < 0.0):
            raise ValueError("Time must be non-negative.")
        y = self.R0 + self.velocity * x
        if np.any(y <= 0.0):
            raise ValueError("Linear radius law became non-positive.")
        if np.ndim(t) == 0:
            return float(y)
        return y

    def dRdt(
        self,
        t: float | Array,
        knot_side: KnotDerivativeSide = "average",
    ) -> float | Array:
        x = np.asarray(t, dtype=float)
        y = np.full_like(x, self.velocity, dtype=float)
        if np.ndim(t) == 0:
            return float(y)
        return y


@dataclass(frozen=True)
class MaterialGrid:
    """Cell-centered material grid on xi in [0,1]."""

    N: int
    xi_faces: Array
    xi_centers: Array
    dxi: float
    # Per-unit-pi-L reference measures:
    # physical volume = pi*L*R^2*volume_weight
    # physical face area = pi*L*R*area_weight
    volume_weight: Array
    area_weight: Array

    @classmethod
    def build(cls, N: int) -> "MaterialGrid":
        if int(N) != N or N < 2:
            raise ValueError("N must be an integer >= 2.")
        N = int(N)
        dxi = 1.0 / N
        xi_faces = np.linspace(0.0, 1.0, N + 1)
        xi_centers = (np.arange(N, dtype=float) + 0.5) * dxi

        # V_i = pi L R^2 (xi_{i+1}^2 - xi_i^2)
        volume_weight = xi_faces[1:] ** 2 - xi_faces[:-1] ** 2

        # A_j = 2 pi L R xi_j = pi L R * (2 xi_j)
        area_weight = 2.0 * xi_faces

        return cls(
            N=N,
            xi_faces=xi_faces,
            xi_centers=xi_centers,
            dxi=dxi,
            volume_weight=volume_weight,
            area_weight=area_weight,
        )

    def physical_geometry(
        self,
        t: float,
        radius_law,
        length: float = 1.0,
    ) -> dict[str, Array | float]:
        if length <= 0.0:
            raise ValueError("Cylinder length must be positive.")

        R = float(radius_law.radius(t))
        dRdt = float(radius_law.dRdt(t))

        r_faces = R * self.xi_faces
        r_centers = R * self.xi_centers
        dr = R * self.dxi
        areas = 2.0 * np.pi * length * r_faces
        volumes = np.pi * length * (
            r_faces[1:] ** 2 - r_faces[:-1] ** 2
        )

        return {
            "R": R,
            "dRdt": dRdt,
            "inv_R": 1.0 / R,
            "inv_R2": 1.0 / (R * R),
            "dr": dr,
            "r_faces": r_faces,
            "r_centers": r_centers,
            "areas": areas,
            "volumes": volumes,
            "surface_area": areas[-1],
            "total_volume": float(np.sum(volumes)),
            "surface_area_to_volume": float(areas[-1] / np.sum(volumes)),
        }

    def material_velocity(
        self,
        t: float,
        radius_law,
        at: Literal["faces", "centers"] = "centers",
    ) -> Array:
        """u = xi * dR/dt under affine radial material shrinkage."""
        dRdt = float(radius_law.dRdt(t))
        xi = self.xi_centers if at == "centers" else self.xi_faces
        return xi * dRdt


def physical_fvm_diffusion_divergence(
    u: Array,
    k_cell: Array,
    t: float,
    grid: MaterialGrid,
    radius_law,
) -> Array:
    """Physical-coordinate cylindrical FVM diffusion divergence with zero flux at both ends.

    This function is only a geometry/operator regression helper.
    """
    u = np.asarray(u, dtype=float)
    k_cell = np.asarray(k_cell, dtype=float)
    if u.shape != (grid.N,) or k_cell.shape != (grid.N,):
        raise ValueError("u and k_cell must have shape (N,).")

    g = grid.physical_geometry(t, radius_law, length=1.0)
    dr = float(g["dr"])
    areas = np.asarray(g["areas"])
    volumes = np.asarray(g["volumes"])

    k_face = 2.0 * k_cell[:-1] * k_cell[1:] / (k_cell[:-1] + k_cell[1:])
    flux = np.zeros(grid.N + 1)
    flux[1:grid.N] = -k_face * (u[1:] - u[:-1]) / dr

    # divergence of k grad u = -(net outward conductive/diffusive flux)/V
    # with flux = -k grad u:
    return (areas[:-1] * flux[:-1] - areas[1:] * flux[1:]) / volumes


def mapped_fvm_diffusion_divergence(
    u: Array,
    k_cell: Array,
    t: float,
    grid: MaterialGrid,
    radius_law,
) -> Array:
    """Same operator assembled directly on xi.

    Implements the transformed factor

        1/(R^2 xi) d/dxi [ xi k du/dxi ]

    in conservative cell-centered FVM form, with zero flux at xi=0 and xi=1.
    """
    u = np.asarray(u, dtype=float)
    k_cell = np.asarray(k_cell, dtype=float)
    if u.shape != (grid.N,) or k_cell.shape != (grid.N,):
        raise ValueError("u and k_cell must have shape (N,).")

    R = float(radius_law.radius(t))
    k_face = 2.0 * k_cell[:-1] * k_cell[1:] / (k_cell[:-1] + k_cell[1:])

    # q_xi := -k du/dxi
    flux_xi = np.zeros(grid.N + 1)
    flux_xi[1:grid.N] = -k_face * (u[1:] - u[:-1]) / grid.dxi

    # A*q/V after cancellation of pi*L and R factors.
    # area_weight=2xi; volume_weight=(xi_R^2-xi_L^2)
    return (
        grid.area_weight[:-1] * flux_xi[:-1]
        - grid.area_weight[1:] * flux_xi[1:]
    ) / (R * R * grid.volume_weight)


def surface_derivative_physical_from_xi(
    u_surface: float,
    u_last: float,
    u_prev: float,
    R: float,
    dxi: float,
) -> float:
    """Second-order Q1/Q2/Q3 surface derivative transformed to physical r."""
    du_dxi = (8.0 * u_surface - 9.0 * u_last + u_prev) / (3.0 * dxi)
    return du_dxi / R


def surface_derivative_physical_direct(
    u_surface: float,
    u_last: float,
    u_prev: float,
    dr: float,
) -> float:
    """The fixed-physical-grid formula used by Q1-Q3."""
    return (8.0 * u_surface - 9.0 * u_last + u_prev) / (3.0 * dr)
