# Q4 Project Manifest

- `README.md` — 2,534 bytes — SHA256 `a521ac51ba40b9db74d8145adb1a17ad38749e1dc20111f1af18c95b0aa52918`
- `data/附件1.xlsx` — 16,586 bytes — SHA256 `7ef32870abeef420b89560b2530ff60dfe4255917805151d89988d0311af9dd7`
- `data/附件2.xlsx` — 11,485 bytes — SHA256 `5563acbfa4b4afb10cc6c03e2207e5369bf39da27576672aff14cc5c32e704af`
- `docs/Q4_模型调整反馈_简版.md` — 4,401 bytes — SHA256 `20243d58e26250da3e3a8dfc5ca85c32d5f8fa61d60813541b4401846e089688`
- `docs/Q4_第四问完整建模方案_数值分析专家交接.md` — 38,731 bytes — SHA256 `c4806d5aa3a9de42726bbb4c800d844608d5c12146c204ed1df52934b2aaf4d1`
- `environment.yml` — 195 bytes — SHA256 `95bed6061459bcdabb523b407cca5224d8e45b48c02693f0311c41b2bb86cfa5`
- `notebooks/Q4_analysis.ipynb` — 21,785 bytes — SHA256 `620425eebd515a3fedddd1dc0865e66012f994dc44cd65e564013d64fdec03f3`
- `requirements.txt` — 95 bytes — SHA256 `e2f3259f7260ff8947ba28e90fdb779b9d68693a7cc8e32d1fabd0f0f470fa2f`
- `src/__pycache__/q2_solver.cpython-313.pyc` — 68,365 bytes — SHA256 `741e5df0b6bb09cc50d316cd91efaa98b11c62ef547712626edb0408904b852c`
- `src/__pycache__/q3_solver.cpython-313.pyc` — 73,783 bytes — SHA256 `f058e2a0d101431a8124938c36234ab5afaf93522b5030b22f971abbe1383aee`
- `src/__pycache__/q4_solver.cpython-313.pyc` — 64,163 bytes — SHA256 `7b47d8114ab51434ff0ca475526859276711c83a11141e3fc4d5cc95817172c0`
- `src/q2_solver.py` — 43,054 bytes — SHA256 `0c0da42aaf5b37f8d2173dda884c053bb26b69580d4bcbfaa1b1278537b792e7`
- `src/q3_solver.py` — 52,065 bytes — SHA256 `cc42ef45501ed97a2f604fda31b2d805037e42edeee518494c68d7a0bfb7b447`
- `src/q4_geometry_core.py` — 12,511 bytes — SHA256 `6576520b03637df100958734d17c2097eb19f044a787f204c4682e2212f39b68`
- `src/q4_solver.py` — 38,706 bytes — SHA256 `ff8d277e2212f9624cfeab3faa76a4d5715d27da1b8d13e19e9824521ef23c65`
- `tests/test_q4_fixed_radius_degeneracy.py` — 9,832 bytes — SHA256 `887b282ef08104f91d392ed746642e74ddaf6037335cd337b04def40f62e189b`
- `validation/FULL_FIXED_RADIUS_DEGENERATION_REPORT.md` — 3,693 bytes — SHA256 `3dde6fd24e85fb75bbaa93e3ef6b163e0f9ce9d582ef9e0374962d680fe073ae`
- `validation/GEOMETRY_ONLY_DEGENERATION_REPORT.md` — 6,563 bytes — SHA256 `30081964b36522673efa0dc434e5bc0b353f4ba0634d3f3925a91cf2427fc785`
