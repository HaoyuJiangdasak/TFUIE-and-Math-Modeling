
from pathlib import Path
import numpy as np

from q1_solver import (
    EnvironmentData,
    Q1Parameters,
    RadialGrid,
    moisture_diffusivity,
    reconstruct_center,
    solve_q1,
    physical_diagnostics,
)


def test_environment_data(env_path):
    p = Q1Parameters()
    env = EnvironmentData.from_excel(env_path)
    env.validate_q1_range(p)
    assert abs(env.T_inf(0.0) - 28.0) < 1e-12
    assert np.isfinite(env.C_inf(1800.0))


def test_cell_centered_geometry():
    p = Q1Parameters()
    g = RadialGrid.build(N=40, R=p.R, L=p.L)
    assert abs(g.faces[0]) < 1e-15
    assert abs(g.faces[-1] - p.R) < 1e-15
    assert abs(g.centers[0] - g.dr / 2.0) < 1e-15


def test_center_reconstruction_even_quadratic():
    dr = 0.1
    # u(r)=3+2r^2, evaluated at r=dr/2 and 3dr/2
    u0 = 3 + 2 * (dr / 2) ** 2
    u1 = 3 + 2 * (3 * dr / 2) ** 2
    reconstructed = reconstruct_center(np.array([[u0, u1]]))[0]
    assert abs(reconstructed - 3.0) < 1e-12


def test_diffusivity_positive():
    p = Q1Parameters()
    C = np.array([2.55, 2.0, 1.0, 0.2])
    D = moisture_diffusivity(C, p)
    assert np.all(D > 0)


def test_short_run(env_path):
    sol = solve_q1(
        env_path,
        N=40,
        t_eval=np.arange(0.0, 61.0, 1.0),
    )
    d = physical_diagnostics(sol)
    assert d["T_min"] >= 27.999999
    assert d["C_min"] > 0.0
