
# Q1 药材烘干：数值求解工程

## 1. 最终主方案

生产代码采用：

**圆柱坐标 cell-centered 有限体积**
→ **Robin 边界二阶重构**
→ **水分表面 Picard 更新 \(D(C_s)\)**
→ **Method of Lines**
→ **SciPy BDF 自适应隐式积分**

这仍然沿用交接说明中的“守恒型有限体积空间半离散 + SciPy BDF/Radau”路线，但对表面 Robin 做了更严格的二阶处理。

### 为什么不直接把求解网格设成 0.1 cm

题目 0.1 cm 是输出间隔，不是数值网格。水分方程在 \(t=0\) 存在“均匀初值 vs 非零 Robin 通量”的初边值不相容，早期表面梯度很陡。实际加密测试表明：
- `N=80` 对水分表面远远不够；
- 二阶 Robin 重构后，`N=640` 与 `N=1280` 在题目要求的 `1 s × 0.1 cm` 输出网上最大差异约为 `2.5e-5 kg/kg`；
- 因此默认正式网格设为 `N=640`。

`R=2 cm` 时：
- `N=640`
- `dr=0.003125 cm`
- 每个 0.1 cm 输出间隔内约有 32 个有限体积单元。

## 2. 中心怎么处理

本实现没有在 `r=0` 放储存节点。

第一个控制体是：
\[
0<r<\Delta r
\]

其左边界就是轴线 `r=0`，该面的圆柱面积为 0，同时轴对称通量为 0。

所以中心不存在 `1/r` 除零问题。

题目要求的 `r=0` 数值用轴对称偶函数展开重构：
\[
u(0)\approx \frac{9u_0-u_1}{8}.
\]

## 3. Robin 边界怎么处理

最后两个单元中心位于：
- `R-dr/2`
- `R-3dr/2`

用二次多项式在表面重构导数：
\[
u_r(R)\approx
\frac{8u_s-9u_{N-1}+u_{N-2}}{3\Delta r}.
\]

### 温度

\[
-kT_r(R)=h(T_s-T_\infty)
\]

直接得到：
\[
T_s=
\frac{
9kT_{N-1}-kT_{N-2}+3\Delta r hT_\infty
}{
8k+3\Delta r h
}.
\]

然后表面通量：
\[
q_s=h(T_s-T_\infty).
\]

### 水分

\[
-D(C_s)C_r(R)=h_m(C_s-C_\infty)
\]

因为 `D` 依赖 `C_s`，每次 RHS 评估时做一个很小的标量 Picard 迭代：
1. 用上一轮 `C_s` 算 `D(C_s)`；
2. 固定 `D` 后解析求新的 `C_s`；
3. 直到表面值收敛。

没有使用人为截断。

## 4. 初值和 Robin 在 t=0 的不相容

水分初始条件是全域 `C=2.55`，因此初始空间导数为 0。

但 `C_inf(0)=0.01963`，Robin 边界立即要求非零向外通量。

所以在数学上，`t=0` 的初始函数与边界导数并不兼容。标准抛物型问题会在 `t=0+` 形成快速边界层。

处理方式：
- ODE 求解从 `t=0+` 按 Robin 通量推进；
- 题目要求输出的精确 `t=0` 仍按初始条件写成 `2.55`；
- 不通过改初值来“强行兼容”。

这也是必须做较细空间网格的主要原因之一。

## 5. 时间积分

默认：
- BDF
- `rtol=1e-9`
- `atol=1e-11`
- `max_step=1 s`

`1 s` 不是显式稳定步长，而只是给自适应 BDF 的最大步长限制。

在 `N=640` 下，显式 Euler 的保守热扩散稳定步长仅约毫秒量级，所以不采用显式法。

## 6. 环境安装

### Conda

```bash
conda env create -f environment.yml
conda activate q1_drying
python -m ipykernel install --user --name q1_drying --display-name "Python (q1_drying)"
```

### venv + pip

```bash
python -m venv .venv
```

Windows:

```powershell
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m ipykernel install --user --name q1_drying --display-name "Python (q1_drying)"
```

macOS/Linux:

```bash
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m ipykernel install --user --name q1_drying --display-name "Python (q1_drying)"
```

## 7. 命令行运行

项目根目录：

```bash
python src/q1_solver.py \
  --env data/附件1.xlsx \
  --output outputs/result1_generated.xlsx \
  --N 640 \
  --method BDF \
  --rtol 1e-9 \
  --atol 1e-11 \
  --max-step 1
```

Windows PowerShell 一行版：

```powershell
python src/q1_solver.py --env "data/附件1.xlsx" --output "outputs/result1_generated.xlsx" --N 640 --method BDF --rtol 1e-9 --atol 1e-11 --max-step 1
```

如果拿到附件 3 的官方 `result1.xlsx`：

```bash
python src/q1_solver.py \
  --env data/附件1.xlsx \
  --template data/result1.xlsx \
  --output outputs/result1.xlsx
```

## 8. 正式提交前的验收

### 空间收敛
运行：
- N=320
- N=640
- N=1280

比较题目实际要求的完整输出网格：
- 时间 0,1,...,1800 s
- 半径 0,0.1,...,2.0 cm

### 时间积分敏感性
比较：
- 正式：`rtol=1e-9, atol=1e-11, max_step=1`
- 更严：`rtol=2e-10, atol=2e-12, max_step=0.5`

### 物理检查
- `T>0`
- `C>0`
- 加热时表面温度高于中心
- 干燥时中心含水率高于表面

### 守恒
比较：
- 域内显热变化 vs 表面对流累计热量
- 域内 `C` 体积分变化 vs 表面累计传质通量

## 9. 文件

- `src/q1_solver.py`：完整生产求解器
- `Q1_analysis.ipynb`：从数据检查到收敛、输出的完整 notebook
- `tests/test_q1_physics.py`：基础单元测试
- `outputs/result1_baseline_N640.xlsx`：当前模型下的基线输出；由于官方附件 3 模板未上传，它是同结构工作簿，不是官方模板原件
