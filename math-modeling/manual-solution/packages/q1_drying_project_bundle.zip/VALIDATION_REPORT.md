# Q1 baseline numerical validation

Production grid: N=640
dr = 0.00312500 cm

## 640 vs 1280 on required 1 s x 0.1 cm grid
E_T_max = 2.58942245e-06 degC
E_C_max = 2.50872114e-05 kg/kg
E_T_rms = 1.86244776e-06
E_C_rms = 3.58393930e-06

## Time-integrator sensitivity: production vs tighter
E_T_max = 9.88415721e-07 degC
E_C_max = 1.59393245e-08 kg/kg

## Physical range
T_min = 28.00000000
T_max = 36.78556092
C_min = 1.51023301
C_max = 2.55000000

## Independent Robin residual for t>0
heat relative max = 4.88117714e-06
moisture relative max = 3.57672356e-03

## Conservation
heat relative max = 9.46135617e-08
moisture relative max = 1.39081922e-06

## Workbook
{'温度': [1802, 22], '水分浓度': [1802, 22]}

## Paper table at t=1800 s
Temperature:
0 cm      33.5753
0.5 cm    33.7720
1 cm      34.3642
1.5 cm    35.3621
2 cm      36.7856

Moisture:
0 cm      2.5500
0.5 cm    2.5497
1 cm      2.5383
1.5 cm    2.3755
2 cm      1.5102
