
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd
from openpyxl import Workbook, load_workbook
from scipy.integrate import cumulative_trapezoid, solve_ivp
from scipy.sparse import diags


@dataclass(frozen=True)
class Q1Parameters:
    """Problem 1 parameters. SI units; temperature stored in degC."""
    R: float = 0.02              # m
    L: float = 0.25              # m
    rho: float = 820.0           # kg/m^3
    cp: float = 2600.0           # J/(kg K)
    k: float = 0.36              # W/(m K)
    h: float = 25.0              # W/(m^2 K)
    hm: float = 8.0e-7           # m/s
    D_prefactor: float = 7.0e-9  # m^2/s
    D_beta: float = 0.89
    T0: float = 28.0             # degC
    C0: float = 2.55             # kg/kg
    t_end: float = 1800.0        # s

    @property
    def alpha(self) -> float:
        return self.k / (self.rho * self.cp)


@dataclass(frozen=True)
class SolverConfig:
    method: str = "BDF"          # "BDF" or "Radau"
    rtol: float = 1.0e-9
    atol: float = 1.0e-11
    max_step: float = 1.0        # s; an accuracy cap, not the output interval


@dataclass
class EnvironmentData:
    t: np.ndarray
    temperature: np.ndarray
    moisture: np.ndarray

    @classmethod
    def from_excel(cls, path: str | Path, sheet_name=0) -> "EnvironmentData":
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Environment file not found: {path}")

        df = pd.read_excel(path, sheet_name=sheet_name)
        required = ["时间", "温度", "水分浓度"]
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(
                f"Missing columns {missing}. Found columns: {list(df.columns)}"
            )

        sub = df[required].copy()
        for c in required:
            sub[c] = pd.to_numeric(sub[c], errors="coerce")
        if sub.isna().any().any():
            bad = sub[sub.isna().any(axis=1)]
            raise ValueError(f"Non-numeric or missing values found:\n{bad}")

        sub = sub.sort_values("时间").reset_index(drop=True)
        t = sub["时间"].to_numpy(dtype=float)
        T = sub["温度"].to_numpy(dtype=float)
        C = sub["水分浓度"].to_numpy(dtype=float)

        if len(t) < 2:
            raise ValueError("At least two environment data points are required.")
        if np.any(np.diff(t) <= 0):
            raise ValueError("Environment time values must be strictly increasing.")

        return cls(t=t, temperature=T, moisture=C)

    def _interp_checked(self, x, y):
        xa = np.asarray(x, dtype=float)
        if np.any(xa < self.t[0] - 1e-12) or np.any(xa > self.t[-1] + 1e-12):
            raise ValueError(
                f"Requested time outside environment data range "
                f"[{self.t[0]}, {self.t[-1]}] s."
            )
        out = np.interp(xa, self.t, y)
        if np.ndim(x) == 0:
            return float(out)
        return out

    def T_inf(self, t):
        return self._interp_checked(t, self.temperature)

    def C_inf(self, t):
        return self._interp_checked(t, self.moisture)

    def validate_q1_range(self, p: Q1Parameters) -> None:
        if self.t[0] > 0 or self.t[-1] < p.t_end:
            raise ValueError(
                f"Environment data must cover 0..{p.t_end} s; "
                f"actual range is {self.t[0]}..{self.t[-1]} s."
            )


@dataclass(frozen=True)
class RadialGrid:
    """
    Uniform cell-centered cylindrical finite-volume grid.

    There are N annular control volumes:
      face j: r = j*dr, j=0..N
      cell i center: r = (i+1/2)*dr, i=0..N-1

    r=0 and r=R are physical faces, not storage nodes.
    """
    N: int
    R: float
    L: float
    dr: float
    faces: np.ndarray
    centers: np.ndarray
    volume_geom: np.ndarray
    area_geom: np.ndarray
    volume_actual: np.ndarray
    surface_area_actual: float

    @classmethod
    def build(cls, N: int, R: float, L: float) -> "RadialGrid":
        if N < 3:
            raise ValueError("N must be at least 3.")
        dr = R / N
        faces = np.linspace(0.0, R, N + 1)
        centers = 0.5 * (faces[:-1] + faces[1:])

        # Divide cylindrical geometry by pi*L in the RHS:
        # V_actual = pi*L*(r_R^2-r_L^2), A_actual = 2*pi*L*r_face.
        volume_geom = faces[1:] ** 2 - faces[:-1] ** 2
        area_geom = 2.0 * faces

        volume_actual = np.pi * L * volume_geom
        surface_area_actual = 2.0 * np.pi * R * L

        return cls(
            N=N,
            R=R,
            L=L,
            dr=dr,
            faces=faces,
            centers=centers,
            volume_geom=volume_geom,
            area_geom=area_geom,
            volume_actual=volume_actual,
            surface_area_actual=surface_area_actual,
        )


@dataclass
class Q1Solution:
    params: Q1Parameters
    config: SolverConfig
    grid: RadialGrid
    env: EnvironmentData
    t: np.ndarray
    T: np.ndarray  # shape (nt, N), cell-centered
    C: np.ndarray  # shape (nt, N), cell-centered
    heat_solver_stats: dict
    moisture_solver_stats: dict


def moisture_diffusivity(C, p: Q1Parameters):
    C = np.asarray(C, dtype=float)
    if np.any(~np.isfinite(C)):
        raise FloatingPointError("Non-finite moisture value encountered.")
    if np.any(C <= 0.0):
        raise FloatingPointError(
            "Non-positive moisture encountered; aborting instead of clipping."
        )
    return p.D_prefactor * np.exp(-p.D_beta / C)


def harmonic_mean(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    return 2.0 * a * b / (a + b)


def tridiagonal_sparsity(n: int):
    return diags(
        diagonals=[np.ones(n - 1), np.ones(n), np.ones(n - 1)],
        offsets=[-1, 0, 1],
        shape=(n, n),
        format="csc",
    )


# ---------------------------------------------------------------------------
# Boundary reconstruction
# ---------------------------------------------------------------------------

def reconstruct_center(cell_values: np.ndarray) -> np.ndarray:
    """
    Axisymmetric center value from the first two cell centers.

    For a smooth even expansion u(r)=a+b*r^2+O(r^4),
    centers are at dr/2 and 3dr/2, giving
        u(0) = (9*u_0 - u_1)/8 + O(dr^4).
    """
    if cell_values.shape[-1] < 2:
        raise ValueError("At least two cells are needed for center reconstruction.")
    return (9.0 * cell_values[..., 0] - cell_values[..., 1]) / 8.0


def reconstruct_surface_temperature(
    T_last,
    T_prev,
    Tinf,
    dr: float,
    p: Q1Parameters,
):
    """
    Second-order one-sided Robin reconstruction at r=R.

    Cell centers are located at R-dr/2 and R-3dr/2. Quadratic interpolation gives
        T_r(R) ~= (8*T_s - 9*T_last + T_prev) / (3*dr).

    With -k*T_r = h*(T_s-T_inf):
        (8k + 3dr*h) T_s
        = 9k*T_last - k*T_prev + 3dr*h*T_inf.
    """
    return (
        9.0 * p.k * T_last
        - p.k * T_prev
        + 3.0 * dr * p.h * Tinf
    ) / (8.0 * p.k + 3.0 * dr * p.h)


def reconstruct_surface_moisture(
    C_last,
    C_prev,
    Cinf,
    dr: float,
    p: Q1Parameters,
    tol: float = 1.0e-12,
    max_iter: int = 50,
):
    """
    Picard solution of the nonlinear Robin surface value.

    Quadratic boundary derivative:
        C_r(R) ~= (8*C_s - 9*C_last + C_prev)/(3*dr)

    Robin:
        -D(C_s) C_r(R) = h_m (C_s - C_inf)

    Picard iteration:
        evaluate D at current C_s,
        then solve the resulting scalar linear Robin equation for new C_s.

    The initial guess C_last selects the physically continuous branch near the
    interior state. No artificial clipping is applied.
    """
    C_s = float(C_last)
    for _ in range(max_iter):
        D_s = float(moisture_diffusivity(np.array([C_s]), p)[0])
        C_new = (
            9.0 * D_s * C_last
            - D_s * C_prev
            + 3.0 * dr * p.hm * Cinf
        ) / (8.0 * D_s + 3.0 * dr * p.hm)

        if not np.isfinite(C_new) or C_new <= 0.0:
            raise FloatingPointError(
                f"Invalid Robin Picard iterate at surface: {C_new}"
            )
        if abs(C_new - C_s) <= tol * (1.0 + abs(C_new)):
            return float(C_new)
        C_s = float(C_new)

    raise RuntimeError(
        "Surface moisture Picard iteration did not converge. "
        "Reduce solver step/tolerance or inspect the state."
    )


def surface_temperature_history(sol: Q1Solution):
    Tinf = sol.env.T_inf(sol.t)
    return reconstruct_surface_temperature(
        sol.T[:, -1], sol.T[:, -2], Tinf, sol.grid.dr, sol.params
    )


def surface_moisture_history(sol: Q1Solution, enforce_initial: bool = False):
    Cinf = sol.env.C_inf(sol.t)
    out = np.empty(len(sol.t), dtype=float)
    for j, t in enumerate(sol.t):
        out[j] = reconstruct_surface_moisture(
            sol.C[j, -1],
            sol.C[j, -2],
            Cinf[j],
            sol.grid.dr,
            sol.params,
        )

    # The uniform initial C and the nonzero Robin flux at t=0 are incompatible.
    # For requested output exactly at t=0, the initial condition takes precedence.
    if enforce_initial:
        mask0 = np.isclose(sol.t, 0.0, atol=1e-14)
        out[mask0] = sol.params.C0
    return out


# ---------------------------------------------------------------------------
# Semi-discrete finite-volume RHS
# ---------------------------------------------------------------------------

def make_heat_rhs(grid: RadialGrid, env: EnvironmentData, p: Q1Parameters):
    rho_cp = p.rho * p.cp
    A = grid.area_geom
    V = grid.volume_geom
    dr = grid.dr

    def rhs(t, T):
        # q > 0 means outward (+r) heat flux.
        q = np.zeros(grid.N + 1, dtype=float)

        # Center face r=0 has zero area and zero flux by symmetry.
        q[0] = 0.0

        # Internal conductive faces.
        q[1:-1] = -p.k * np.diff(T) / dr

        # Robin surface flux. Surface value is reconstructed to second order.
        Tinf = env.T_inf(t)
        Ts = reconstruct_surface_temperature(
            T[-1], T[-2], Tinf, dr, p
        )
        q[-1] = p.h * (Ts - Tinf)

        # Conservative balance for every annular control volume:
        # storage = left inflow - right outflow.
        return (A[:-1] * q[:-1] - A[1:] * q[1:]) / (rho_cp * V)

    return rhs


def make_moisture_rhs(grid: RadialGrid, env: EnvironmentData, p: Q1Parameters):
    A = grid.area_geom
    V = grid.volume_geom
    dr = grid.dr

    def rhs(t, C):
        q = np.zeros(grid.N + 1, dtype=float)

        # Symmetry at r=0.
        q[0] = 0.0

        # Nonlinear conservative internal fluxes.
        D_node = moisture_diffusivity(C, p)
        D_face = harmonic_mean(D_node[:-1], D_node[1:])
        q[1:-1] = -D_face * np.diff(C) / dr

        # Nonlinear Robin surface flux.
        Cinf = env.C_inf(t)
        Cs = reconstruct_surface_moisture(
            C[-1], C[-2], Cinf, dr, p
        )
        q[-1] = p.hm * (Cs - Cinf)

        return (A[:-1] * q[:-1] - A[1:] * q[1:]) / V

    return rhs


def solve_q1(
    env_path: str | Path,
    N: int = 640,
    t_eval: Optional[np.ndarray] = None,
    params: Optional[Q1Parameters] = None,
    config: Optional[SolverConfig] = None,
) -> Q1Solution:
    p = params or Q1Parameters()
    cfg = config or SolverConfig()
    env = EnvironmentData.from_excel(env_path)
    env.validate_q1_range(p)
    grid = RadialGrid.build(N=N, R=p.R, L=p.L)

    if t_eval is None:
        t_eval = np.arange(0.0, p.t_end + 1.0, 1.0)
    else:
        t_eval = np.asarray(t_eval, dtype=float)

    if t_eval[0] < -1e-12 or t_eval[-1] > p.t_end + 1e-12:
        raise ValueError("t_eval must stay inside [0, t_end].")
    if np.any(np.diff(t_eval) <= 0):
        raise ValueError("t_eval must be strictly increasing.")

    sparsity = tridiagonal_sparsity(N)
    y0_T = np.full(N, p.T0, dtype=float)
    y0_C = np.full(N, p.C0, dtype=float)

    heat = solve_ivp(
        fun=make_heat_rhs(grid, env, p),
        t_span=(0.0, p.t_end),
        y0=y0_T,
        method=cfg.method,
        t_eval=t_eval,
        rtol=cfg.rtol,
        atol=cfg.atol,
        max_step=cfg.max_step,
        jac_sparsity=sparsity,
    )
    if not heat.success:
        raise RuntimeError(f"Heat solve failed: {heat.message}")

    moisture = solve_ivp(
        fun=make_moisture_rhs(grid, env, p),
        t_span=(0.0, p.t_end),
        y0=y0_C,
        method=cfg.method,
        t_eval=t_eval,
        rtol=cfg.rtol,
        atol=cfg.atol,
        max_step=cfg.max_step,
        jac_sparsity=sparsity,
    )
    if not moisture.success:
        raise RuntimeError(f"Moisture solve failed: {moisture.message}")

    return Q1Solution(
        params=p,
        config=cfg,
        grid=grid,
        env=env,
        t=t_eval,
        T=heat.y.T,
        C=moisture.y.T,
        heat_solver_stats={
            "nfev": heat.nfev,
            "njev": heat.njev,
            "nlu": heat.nlu,
            "message": heat.message,
        },
        moisture_solver_stats={
            "nfev": moisture.nfev,
            "njev": moisture.njev,
            "nlu": moisture.nlu,
            "message": moisture.message,
        },
    )


# ---------------------------------------------------------------------------
# Sampling / output
# ---------------------------------------------------------------------------

def augmented_field(sol: Q1Solution, field_name: str, enforce_initial: bool = True):
    if field_name not in {"T", "C"}:
        raise ValueError("field_name must be 'T' or 'C'.")

    field = sol.T if field_name == "T" else sol.C
    center = reconstruct_center(field)

    if field_name == "T":
        surface = surface_temperature_history(sol)
        if enforce_initial:
            surface[np.isclose(sol.t, 0.0, atol=1e-14)] = sol.params.T0
    else:
        surface = surface_moisture_history(sol, enforce_initial=enforce_initial)

    r_aug = np.concatenate(([0.0], sol.grid.centers, [sol.params.R]))
    field_aug = np.column_stack((center, field, surface))

    if enforce_initial:
        mask0 = np.isclose(sol.t, 0.0, atol=1e-14)
        if np.any(mask0):
            field_aug[mask0, :] = sol.params.T0 if field_name == "T" else sol.params.C0

    return r_aug, field_aug


def sample_solution(
    sol: Q1Solution,
    field_name: str,
    t_query: Iterable[float],
    r_query: Iterable[float],
    enforce_initial: bool = True,
) -> np.ndarray:
    t_query = np.asarray(list(t_query), dtype=float)
    r_query = np.asarray(list(r_query), dtype=float)

    if np.any(t_query < sol.t[0] - 1e-12) or np.any(t_query > sol.t[-1] + 1e-12):
        raise ValueError("Requested time outside numerical solution.")
    if np.any(r_query < -1e-12) or np.any(r_query > sol.params.R + 1e-12):
        raise ValueError("Requested radius outside numerical solution.")

    r_aug, field_aug = augmented_field(sol, field_name, enforce_initial=enforce_initial)

    # Space interpolation at each stored time.
    spatial = np.vstack([np.interp(r_query, r_aug, row) for row in field_aug])

    # Time interpolation at each requested radius.
    out = np.column_stack(
        [np.interp(t_query, sol.t, spatial[:, j]) for j in range(len(r_query))]
    )
    return out


def paper_tables(sol: Q1Solution):
    times = np.array([100, 300, 600, 900, 1200, 1500, 1800], dtype=float)
    radii_cm = np.array([0, 0.5, 1.0, 1.5, 2.0], dtype=float)
    radii_m = radii_cm / 100.0

    T = sample_solution(sol, "T", times, radii_m)
    C = sample_solution(sol, "C", times, radii_m)

    cols = [f"{x:g} cm" for x in radii_cm]
    T_df = pd.DataFrame(np.round(T, 4), index=times.astype(int), columns=cols)
    C_df = pd.DataFrame(np.round(C, 4), index=times.astype(int), columns=cols)
    T_df.index.name = "time/s"
    C_df.index.name = "time/s"
    return T_df, C_df


def result_grid(sol: Q1Solution):
    times = np.arange(0.0, sol.params.t_end + 1.0, 1.0)
    radii_cm = np.arange(0.0, 2.0 + 0.1, 0.1)
    radii_m = radii_cm / 100.0
    T = sample_solution(sol, "T", times, radii_m)
    C = sample_solution(sol, "C", times, radii_m)
    return times, radii_cm, T, C


def _get_or_create_sheet(wb, title: str):
    if title in wb.sheetnames:
        return wb[title]
    return wb.create_sheet(title=title)


def _write_result_sheet(ws, times, radii_cm, values):
    if ws["A1"].value is None:
        ws["A1"] = "时间/s"

    for j, r_cm in enumerate(radii_cm, start=2):
        ws.cell(row=1, column=j, value=float(round(r_cm, 4)))
        ws.cell(row=1, column=j).number_format = "0.0000"

    for i, t in enumerate(times, start=2):
        ws.cell(row=i, column=1, value=int(round(t)))
        for j in range(len(radii_cm)):
            cell = ws.cell(
                row=i,
                column=j + 2,
                value=float(round(values[i - 2, j], 4)),
            )
            cell.number_format = "0.0000"


def write_result1(
    sol: Q1Solution,
    output_path: str | Path,
    template_path: Optional[str | Path] = None,
):
    """
    If an official result1.xlsx template is supplied, preserve it and fill the two
    required sheets. Otherwise create a structurally compatible workbook.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    times, radii_cm, T, C = result_grid(sol)

    if template_path is not None:
        template_path = Path(template_path)
        if not template_path.exists():
            raise FileNotFoundError(f"Template not found: {template_path}")
        wb = load_workbook(template_path)
    else:
        wb = Workbook()
        wb.active.title = "温度"
        wb.create_sheet("水分浓度")

    ws_T = _get_or_create_sheet(wb, "温度")
    ws_C = _get_or_create_sheet(wb, "水分浓度")

    _write_result_sheet(ws_T, times, radii_cm, T)
    _write_result_sheet(ws_C, times, radii_cm, C)

    wb.save(output_path)
    return output_path


# ---------------------------------------------------------------------------
# Numerical validation
# ---------------------------------------------------------------------------

def explicit_stability_reference(N: int = 640, p: Optional[Q1Parameters] = None):
    """
    Conservative order-of-magnitude reference for a naive explicit Euler solver.
    This is intentionally conservative and is NOT a restriction on BDF/Radau.
    """
    p = p or Q1Parameters()
    dr = p.R / N
    Dmax_ref = float(moisture_diffusivity(np.array([p.C0]), p)[0])

    # Use Fo <= 1/4 as a conservative radial-diffusion reference.
    dt_heat = dr**2 / (4.0 * p.alpha)
    dt_moisture = dr**2 / (4.0 * Dmax_ref)
    return {
        "N": N,
        "dr_m": dr,
        "dr_cm": dr * 100.0,
        "alpha_m2_s": p.alpha,
        "D_initial_m2_s": Dmax_ref,
        "dt_explicit_heat_s_conservative": dt_heat,
        "dt_explicit_moisture_s_conservative": dt_moisture,
    }


def boundary_residuals(sol: Q1Solution):
    """
    Independent Robin check.

    Surface values were reconstructed using a quadratic boundary formula.
    Here a different cubic polynomial through the surface and the last three
    cell centers is used:
        u_r(R) ~= (184*u_s - 225*u_1 + 50*u_2 - 9*u_3)/(60*dr).
    """
    if sol.grid.N < 3:
        raise ValueError("At least three cells are needed.")

    p = sol.params
    dr = sol.grid.dr
    Tinf = sol.env.T_inf(sol.t)
    Cinf = sol.env.C_inf(sol.t)
    Ts = surface_temperature_history(sol)
    Cs = surface_moisture_history(sol, enforce_initial=False)

    dTdr = (
        184.0 * Ts
        - 225.0 * sol.T[:, -1]
        + 50.0 * sol.T[:, -2]
        - 9.0 * sol.T[:, -3]
    ) / (60.0 * dr)

    dCdr = (
        184.0 * Cs
        - 225.0 * sol.C[:, -1]
        + 50.0 * sol.C[:, -2]
        - 9.0 * sol.C[:, -3]
    ) / (60.0 * dr)

    heat_res = -p.k * dTdr - p.h * (Ts - Tinf)
    moisture_res = (
        -moisture_diffusivity(Cs, p) * dCdr
        - p.hm * (Cs - Cinf)
    )

    # t=0 moisture IC and Robin BC are incompatible; validate the BC for t>0.
    mask = sol.t > 0.0
    heat_scale = max(float(np.max(np.abs(p.h * (Ts[mask] - Tinf[mask])))), 1e-14)
    moisture_scale = max(
        float(np.max(np.abs(p.hm * (Cs[mask] - Cinf[mask])))), 1e-14
    )

    return {
        "heat_residual": heat_res,
        "moisture_residual": moisture_res,
        "max_abs_heat_residual_t_gt_0": float(np.max(np.abs(heat_res[mask]))),
        "max_abs_moisture_residual_t_gt_0": float(np.max(np.abs(moisture_res[mask]))),
        "max_rel_heat_residual_t_gt_0": float(
            np.max(np.abs(heat_res[mask])) / heat_scale
        ),
        "max_rel_moisture_residual_t_gt_0": float(
            np.max(np.abs(moisture_res[mask])) / moisture_scale
        ),
    }


def conservation_diagnostics(sol: Q1Solution):
    p = sol.params
    V = sol.grid.volume_actual
    A_R = sol.grid.surface_area_actual

    Ts = surface_temperature_history(sol)
    Cs_flux = surface_moisture_history(sol, enforce_initial=False)

    # Heat: dE/dt = A_R*h*(T_inf - T_s)
    E = p.rho * p.cp * np.sum(sol.T * V[None, :], axis=1)
    qin = A_R * p.h * (sol.env.T_inf(sol.t) - Ts)
    Qin = cumulative_trapezoid(qin, sol.t, initial=0.0)
    heat_residual = (E - E[0]) - Qin
    heat_scale = max(float(np.max(np.abs(E - E[0]))), 1e-14)

    # Moisture proxy: dM/dt = -A_R*h_m*(C_s-C_inf)
    M = np.sum(sol.C * V[None, :], axis=1)
    jout = A_R * p.hm * (Cs_flux - sol.env.C_inf(sol.t))
    Mout = cumulative_trapezoid(jout, sol.t, initial=0.0)
    moisture_residual = (M - M[0]) + Mout
    moisture_scale = max(float(np.max(np.abs(M - M[0]))), 1e-14)

    return {
        "heat_residual": heat_residual,
        "moisture_residual": moisture_residual,
        "max_abs_heat_conservation_J": float(np.max(np.abs(heat_residual))),
        "max_rel_heat_conservation": float(
            np.max(np.abs(heat_residual)) / heat_scale
        ),
        "max_abs_moisture_conservation_proxy": float(
            np.max(np.abs(moisture_residual))
        ),
        "max_rel_moisture_conservation": float(
            np.max(np.abs(moisture_residual)) / moisture_scale
        ),
    }


def physical_diagnostics(sol: Q1Solution):
    rT, Tall = augmented_field(sol, "T", enforce_initial=True)
    rC, Call = augmented_field(sol, "C", enforce_initial=True)

    # Expected in Q1: T rises toward surface; C falls toward surface.
    radial_T_violation = np.maximum(-np.diff(Tall, axis=1), 0.0)
    radial_C_violation = np.maximum(np.diff(Call, axis=1), 0.0)
    time_T_violation = np.maximum(-np.diff(Tall, axis=0), 0.0)
    time_C_violation = np.maximum(np.diff(Call, axis=0), 0.0)

    return {
        "T_min": float(np.min(Tall)),
        "T_max": float(np.max(Tall)),
        "C_min": float(np.min(Call)),
        "C_max": float(np.max(Call)),
        "max_radial_T_monotonicity_violation": float(
            np.max(radial_T_violation, initial=0.0)
        ),
        "max_radial_C_monotonicity_violation": float(
            np.max(radial_C_violation, initial=0.0)
        ),
        "max_time_T_monotonicity_violation": float(
            np.max(time_T_violation, initial=0.0)
        ),
        "max_time_C_monotonicity_violation": float(
            np.max(time_C_violation, initial=0.0)
        ),
    }


def compare_solutions(
    coarse: Q1Solution,
    fine: Q1Solution,
    t_query: Optional[np.ndarray] = None,
    r_query_m: Optional[np.ndarray] = None,
):
    if t_query is None:
        t_query = np.arange(0.0, coarse.params.t_end + 1.0, 1.0)
    if r_query_m is None:
        r_query_m = np.arange(0.0, coarse.params.R + 0.0005, 0.001)

    Tc = sample_solution(coarse, "T", t_query, r_query_m)
    Tf = sample_solution(fine, "T", t_query, r_query_m)
    Cc = sample_solution(coarse, "C", t_query, r_query_m)
    Cf = sample_solution(fine, "C", t_query, r_query_m)

    return {
        "E_T_max": float(np.max(np.abs(Tf - Tc))),
        "E_C_max": float(np.max(np.abs(Cf - Cc))),
        "E_T_rms": float(np.sqrt(np.mean((Tf - Tc) ** 2))),
        "E_C_rms": float(np.sqrt(np.mean((Cf - Cc) ** 2))),
    }


def grid_convergence_study(
    env_path: str | Path,
    N_values=(320, 640, 1280),
    params: Optional[Q1Parameters] = None,
    config: Optional[SolverConfig] = None,
):
    p = params or Q1Parameters()
    cfg = config or SolverConfig()
    sols = {}

    for N in N_values:
        sols[N] = solve_q1(env_path, N=N, params=p, config=cfg)

    rows = []
    for Nc, Nf in zip(N_values[:-1], N_values[1:]):
        err = compare_solutions(sols[Nc], sols[Nf])
        rows.append({"coarse_N": Nc, "fine_N": Nf, **err})

    df = pd.DataFrame(rows)
    if len(df) >= 2:
        for key in ["T", "C"]:
            e1 = df.iloc[0][f"E_{key}_max"]
            e2 = df.iloc[1][f"E_{key}_max"]
            p_obs = (
                np.log(e1 / e2) / np.log(2.0)
                if e1 > 0 and e2 > 0
                else np.nan
            )
            df[f"observed_order_{key}"] = np.nan
            df.loc[df.index[-1], f"observed_order_{key}"] = p_obs

    return df, sols


def print_summary(sol: Q1Solution):
    print("=== Q1 numerical summary ===")
    print(f"N = {sol.grid.N} cells")
    print(f"dr = {sol.grid.dr:.6e} m = {sol.grid.dr * 100:.6f} cm")
    print(
        f"method = {sol.config.method}, rtol = {sol.config.rtol:g}, "
        f"atol = {sol.config.atol:g}, max_step = {sol.config.max_step:g} s"
    )
    print("heat solver:", sol.heat_solver_stats)
    print("moisture solver:", sol.moisture_solver_stats)
    print("explicit-Euler reference:", explicit_stability_reference(sol.grid.N, sol.params))
    print("physical diagnostics:", physical_diagnostics(sol))
    print(
        "boundary residuals:",
        {
            k: v
            for k, v in boundary_residuals(sol).items()
            if not isinstance(v, np.ndarray)
        },
    )
    print(
        "conservation diagnostics:",
        {
            k: v
            for k, v in conservation_diagnostics(sol).items()
            if not isinstance(v, np.ndarray)
        },
    )


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Q1 solver: cell-centered cylindrical FVM + second-order Robin "
            "reconstruction + SciPy BDF/Radau."
        )
    )
    parser.add_argument("--env", required=True, help="Path to 附件1.xlsx")
    parser.add_argument("--output", default="result1.xlsx", help="Output workbook path")
    parser.add_argument(
        "--template", default=None, help="Optional official result1.xlsx template"
    )
    parser.add_argument("--N", type=int, default=640, help="Number of radial cells")
    parser.add_argument("--method", choices=["BDF", "Radau"], default="BDF")
    parser.add_argument("--rtol", type=float, default=1e-9)
    parser.add_argument("--atol", type=float, default=1e-11)
    parser.add_argument("--max-step", type=float, default=1.0)
    args = parser.parse_args()

    cfg = SolverConfig(
        method=args.method,
        rtol=args.rtol,
        atol=args.atol,
        max_step=args.max_step,
    )
    sol = solve_q1(args.env, N=args.N, config=cfg)
    print_summary(sol)

    T_df, C_df = paper_tables(sol)
    print("\nTable 1 - temperature:")
    print(T_df.to_string())
    print("\nTable 2 - moisture:")
    print(C_df.to_string())

    out = write_result1(sol, args.output, template_path=args.template)
    print(f"\nSaved: {out}")


if __name__ == "__main__":
    main()
